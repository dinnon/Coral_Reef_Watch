"""Small I/O helpers: polite HTTP with retries, atomic file writes."""

from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path

import pandas as pd
import requests

USER_AGENT = "onms-crw-pipeline/0.1 (ONMS Coral Reef Watch boundary summaries)"
_session: requests.Session | None = None


class FetchError(RuntimeError):
    pass


def session() -> requests.Session:
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers["User-Agent"] = USER_AGENT
    return _session


def get(url: str, *, timeout: float = 180, attempts: int = 4, stream_to: Path | None = None) -> bytes | Path:
    """GET with exponential backoff. Retries 429/5xx and network errors only."""
    delay = 5.0
    for attempt in range(1, attempts + 1):
        try:
            with session().get(url, timeout=timeout, stream=stream_to is not None) as r:
                if r.status_code in (429, 500, 502, 503, 504):
                    raise FetchError(f"HTTP {r.status_code}")
                if r.status_code >= 400:
                    # ERDDAP explains bad requests in the body; surface it, don't retry.
                    raise FetchError(f"HTTP {r.status_code} for {url}\n{r.text[:500]}")
                if stream_to is None:
                    return r.content
                stream_to.parent.mkdir(parents=True, exist_ok=True)
                tmp = stream_to.with_suffix(stream_to.suffix + ".part")
                with open(tmp, "wb") as fh:
                    for chunk in r.iter_content(1 << 20):
                        fh.write(chunk)
                os.replace(tmp, stream_to)
                return stream_to
        except (requests.ConnectionError, requests.Timeout, FetchError) as err:
            permanent = isinstance(err, FetchError) and "HTTP 4" in str(err) and "429" not in str(err)
            if permanent or attempt == attempts:
                raise FetchError(f"{url}: {err}") from err
            time.sleep(delay)
            delay *= 2
    raise AssertionError("unreachable")


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("wb", dir=path.parent, prefix=".tmp-", delete=False) as fh:
        fh.write(data)
        tmp = Path(fh.name)
    os.chmod(tmp, 0o644)  # NamedTemporaryFile is 0600; published files must be world-readable
    os.replace(tmp, path)


def write_csv(path: Path, df: pd.DataFrame, float_format: str = "%.4f") -> None:
    atomic_write_bytes(path, df.to_csv(index=False, float_format=float_format,
                                       lineterminator="\n").encode("utf-8"))


def write_json(path: Path, obj) -> None:
    atomic_write_bytes(path, (json.dumps(obj, indent=1, ensure_ascii=False, default=str) + "\n").encode("utf-8"))
