"""ONMS boundary download, normalisation (incl. antimeridian) and export."""

from __future__ import annotations

import hashlib
import json
import warnings
import zipfile
from dataclasses import dataclass
from pathlib import Path

import geopandas as gpd
import numpy as np
import shapely
from shapely.geometry import mapping
from pyproj import Geod
from shapely.ops import transform

from . import io
from .config import Config, Site

_GEOD = Geod(ellps="WGS84")
ALL = "ALL"  # series name for the whole-sanctuary summary


@dataclass
class Boundary:
    site: Site
    frame: int                       # 180 -> lon in [-180, 180); 360 -> lon in [0, 360)
    whole: shapely.Geometry          # dissolved sanctuary geometry (frame coords)
    units: dict[str, shapely.Geometry]
    source_layer: str
    digest: str                      # changes when the geometry changes

    def series(self) -> dict[str, shapely.Geometry]:
        out = {ALL: self.whole}
        out.update(self.units)
        return out


def zip_path(cfg: Config, site: Site) -> Path:
    return cfg.cache_dir / "boundaries" / f"{site.slug}.zip"


def download(cfg: Config, site: Site, refresh: bool = False) -> Path:
    path = zip_path(cfg, site)
    if refresh or not path.exists():
        io.get(site.boundary_url, stream_to=path)
    return path


def list_layers(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as z:
        return sorted(n for n in z.namelist() if n.lower().endswith(".shp") and "__macosx" not in n.lower())


def _pick_layer(path: Path, site: Site) -> str:
    layers = list_layers(path)
    if not layers:
        raise ValueError(f"{site.code}: no shapefile inside {path.name}")
    if len(layers) == 1:
        return layers[0]
    # iMAST zips sometimes bundle zones or lines with the boundary.
    polys = []
    for name in layers:
        gdf = gpd.read_file(f"zip://{path}!{name}")
        if gdf.geom_type.isin(["Polygon", "MultiPolygon"]).all():
            polys.append((name, gdf))
    if not polys:
        raise ValueError(f"{site.code}: no polygon layer among {layers}")
    preferred = [n for n, _ in polys if site.slug in Path(n).stem.lower() and "py" in Path(n).stem.lower()]
    choice = preferred[0] if preferred else max(polys, key=lambda p: p[1].to_crs(6933).area.sum())[0]
    warnings.warn(f"{site.code}: several layers in {path.name} ({', '.join(layers)}); using {choice}. "
                  "Set `layer` handling in boundaries.py if that is wrong.")
    return choice


def read_raw(path: Path, site: Site) -> tuple[gpd.GeoDataFrame, str]:
    layer = _pick_layer(path, site)
    gdf = gpd.read_file(f"zip://{path}!{layer}")
    if gdf.crs is None:
        warnings.warn(f"{site.code}: {layer} has no .prj; assuming geographic WGS84")
        gdf = gdf.set_crs(4326)
    elif not gdf.crs.equals(4326):
        gdf = gdf.to_crs(4326)
    gdf = gdf[gdf.geometry.notna() & ~gdf.geometry.is_empty]
    gdf["geometry"] = shapely.make_valid(gdf.geometry.values)
    return gdf, layer


def _all_lons(geoms) -> np.ndarray:
    coords = shapely.get_coordinates(np.asarray(list(geoms), dtype=object))
    return coords[:, 0]


def choose_frame(geoms) -> int:
    """360 when the shapes straddle the antimeridian, else 180."""
    lons = _all_lons(geoms)
    if lons.size == 0:
        return 180
    if lons.max() > 180:
        return 360
    wrapped = np.where(lons < 0, lons + 360, lons)
    span180 = lons.max() - lons.min()
    span360 = wrapped.max() - wrapped.min()
    return 360 if span360 + 1e-9 < span180 and span180 > 180 else 180


def to_frame(geom, frame: int):
    """Express a geometry in the chosen longitude frame."""
    if frame == 180:
        return geom
    return transform(lambda x, y, z=None: (np.where(np.asarray(x) < 0, np.asarray(x) + 360, x), y), geom)


def _clean(geom):
    geom = shapely.make_valid(geom)
    if geom.geom_type == "GeometryCollection":
        geom = shapely.union_all([g for g in geom.geoms if g.geom_type in ("Polygon", "MultiPolygon")])
    # Snap away hairline gaps created where polygons were split at ±180.
    return shapely.make_valid(geom.buffer(1e-7).buffer(-1e-7)) if not geom.is_empty else geom


def build(gdf: gpd.GeoDataFrame, site: Site, layer: str) -> Boundary:
    frame = choose_frame(gdf.geometry.values)
    shifted = [to_frame(g, frame) for g in gdf.geometry.values]
    whole = _clean(shapely.union_all(shifted))
    units: dict[str, shapely.Geometry] = {}
    if site.unit_field:
        if site.unit_field not in gdf.columns:
            raise ValueError(f"{site.code}: unit_field {site.unit_field!r} not in {list(gdf.columns)}")
        for name, idx in gdf.groupby(gdf[site.unit_field].astype(str)).groups.items():
            units[name.strip()] = _clean(shapely.union_all([shifted[gdf.index.get_loc(i)] for i in idx]))
    digest = hashlib.sha256(shapely.to_wkb(whole) + b"".join(
        k.encode() + shapely.to_wkb(v) for k, v in sorted(units.items()))).hexdigest()[:16]
    return Boundary(site, frame, whole, units, layer, digest)


def load(cfg: Config, site: Site, refresh: bool = False) -> Boundary:
    path = download(cfg, site, refresh)
    gdf, layer = read_raw(path, site)
    return build(gdf, site, layer)


def area_km2(geom, frame: int = 180) -> float:
    """Geodesic area; valid in either longitude frame because only edge deltas matter."""
    area, _ = _GEOD.geometry_area_perimeter(shapely.orient_polygons(geom) if hasattr(shapely, "orient_polygons") else geom)
    return abs(area) / 1e6


def export_geojson(b: Boundary, path: Path, tolerance: float = 0.002) -> None:
    feats = []
    for name, geom in b.series().items():
        simple = geom.simplify(tolerance, preserve_topology=True)
        feats.append({"type": "Feature", "properties": {"series": name,
                                                         "area_km2": round(area_km2(geom, b.frame), 1)},
                      "geometry": mapping(shapely.set_precision(simple, 1e-5))})
    io.write_json(path, {"type": "FeatureCollection", "frame": b.frame,
                         "source": b.site.boundary_url, "layer": b.source_layer,
                         "features": feats})


def describe(path: Path, site: Site) -> str:
    lines = [f"{site.code}: {path.name}"]
    for layer in list_layers(path):
        gdf = gpd.read_file(f"zip://{path}!{layer}")
        lines.append(f"  layer {layer}: {len(gdf)} feature(s), {sorted(set(gdf.geom_type))}, crs={gdf.crs}")
        for col in gdf.columns:
            if col == "geometry":
                continue
            vals = gdf[col].astype(str).unique()
            sample = ", ".join(vals[:8]) + (" …" if len(vals) > 8 else "")
            lines.append(f"    {col} ({len(vals)} distinct): {sample}")
        b = gdf.to_crs(4326).total_bounds if gdf.crs else gdf.total_bounds
        lines.append(f"    bounds lon {b[0]:.3f}..{b[2]:.3f}  lat {b[1]:.3f}..{b[3]:.3f}")
    return "\n".join(lines)


def boundary_meta(b: Boundary) -> dict:
    return {"frame": b.frame, "layer": b.source_layer, "digest": b.digest,
            "area_km2": round(area_km2(b.whole, b.frame), 1),
            "units": sorted(b.units)}


def dumps(b: Boundary) -> str:
    return json.dumps(boundary_meta(b))
