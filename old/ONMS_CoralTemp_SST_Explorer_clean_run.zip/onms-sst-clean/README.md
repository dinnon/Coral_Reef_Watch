# Six-sanctuary CoralTemp SST explorer

One Python script builds the data; `index.html` displays its completed monthly series. The six ONMS units are Papahānaumokuākea (PNMS), Hawaiian Islands Humpback Whale (HIHWNMS), American Samoa (NMSAS), Flower Garden Banks (FGBNMS), Florida Keys (FKNMS), and Gray’s Reef (GRNMS). The package contains **no prebuilt SST series**. It does not use the earlier sparse station sample.

## Run from the top

1. Unzip into a **new folder**. Keep it separate from the old prototype folder so its files cannot be mistaken for this result.
2. With an internet connection, open `run_sst.py` in IDLE and choose **Run → Run Module (F5)**. Alternatively, from a terminal in this folder, run `python run_sst.py` (or `py run_sst.py` on Windows). Python 3.10 or newer; no third-party packages. The script prints the output folder and progress. The first run downloads the ONMS polygons, inventories all native 0.05° grid centers inside the six boundaries, and fetches NOAA monthly SST from 1985 onward. **The first backfill may take a long time and substantial disk space, especially for PNMS.**
3. If interrupted, run the same command again in the same folder. It skips completed historical year/latitude-band files and refreshes the current year. Do not delete the `data/chunks` folder if you want to resume. The viewer's summary is published only after every band finishes.
4. Once complete, from this folder run `python -m http.server 8000`, then open `http://localhost:8000` in a browser. This also lets the viewer load the local CSV, stations, and boundaries automatically. To check coordinates **before** the SST download, optionally run `python run_sst.py --plan-only`; the normal run makes the same inventory automatically.

The script writes `data/sanctuary_boundaries.geojson` (NOAA source polygons), `data/stations.csv` (every in-boundary native-grid center), `data/sampling_audit.json` (counts per sanctuary and polygon part), `data/chunks/*.csv` (valid per-cell monthly observations in resumable year/latitude-band files), `data/chunks/*.months.json` (returned monthly slices, including fully masked slices), `data/chunks/index.json` (pixel file list), `data/sst_monthly.csv` (six-site monthly summaries), and `data/run_metadata.json` (provenance and selection hash). No previously uploaded five-site CSV is needed. To rebuild against changed boundaries, use a new clean folder rather than mixing checkpoints from different selections.

## Interpretation and checks

A station is a grid **cell center inside** an ONMS polygon. A partial cell whose center falls outside is excluded, and tiny polygon parts may have no cell center. Check the zero-cell component counts in `sampling_audit.json`. Gray’s Reef is small enough that very few native cells may lie inside it; examine its count before treating its mean as geographically representative.

For each month, valid cell SST values are weighted by `cos(latitude)` to approximate cell area on the 0.05° grid. Missing/land-masked cells are omitted from the mean; `n_valid`, `n_stations`, and `coverage_pct` report data completeness among selected cells. A returned month with no valid cells is retained with `n_valid=0` and blank SST. The anomaly uses each calendar month’s 1991–2020 mean of the new sanctuary series when at least 20 baseline years are available. SST is a surface-water measurement, not reef-depth temperature or bleaching heat stress. This is not a fractional boundary-cell area mean or a coral habitat-weighted metric.

After the first run, review sanctuary boundaries against the station map, audit total and per-component counts, check low-coverage months, and compare several observed months with NOAA’s monthly grid. The summary reflects only months returned for **every** latitude band; this avoids publishing an incompletely downloaded latest month. Future scheduled updates can run this same script after the initial full backfill has been checked; hosting the small summary, boundary, and station files is separate from retaining the potentially large pixel checkpoints.

## Sources

- [ONMS sanctuary boundary FeatureServer](https://services2.arcgis.com/C8EMgrsFcRFL6LrL/arcgis/rest/services/NMS_Boundaries_02032022/FeatureServer/0) ([NOAA InPort record](https://www.fisheries.noaa.gov/inport/item/37245)).
- [NOAA Coral Reef Watch CoralTemp v3.1 monthly SST](https://oceanwatch.pifsc.noaa.gov/erddap/griddap/CRW_sst_v3_1_monthly.html), primary ERDDAP dataset; [NOAA CoastWatch monthly dataset](https://coastwatch.pfeg.noaa.gov/erddap/griddap/NOAA_DHW_monthly.html), fallback. Per-cell checkpoint rows record the dataset used.
