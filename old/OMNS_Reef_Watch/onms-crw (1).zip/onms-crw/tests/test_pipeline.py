from datetime import date

import geopandas as gpd
import numpy as np
import pandas as pd
import pytest
from shapely.geometry import Point, box

from onms_crw import aggregate, boundaries, config, grid, pipeline, stations, stats, synthetic
from onms_crw.config import Site


# ---------------------------------------------------------------- grid
def test_pixel_cover_matches_area():
    geom = box(-81.013, 24.507, -80.488, 24.731)
    inv = grid.inventory(geom, 180)
    assert inv["cover"].sum() * grid.RES ** 2 == pytest.approx(geom.area, rel=1e-6)
    assert inv["cover"].between(0, 1).all()
    assert inv["center_inside"].sum() < len(inv)            # edge pixels kept, partially weighted


def test_grid_indices_roundtrip():
    lats = np.array([-89.975, 0.025, 89.975])
    lons = np.array([-179.975, 0.025, 179.975, 180.025, 359.975])
    assert grid.lat_index(lats).tolist() == [0, 1800, 3599]
    assert grid.lon_index(lons).tolist() == [0, 3600, 7199, 0, 3599]


def test_fetch_windows_split_at_antimeridian():
    inv = grid.inventory(box(179.0, 20, 182.0, 21), 360)
    wins = grid.fetch_windows(inv["iy"].to_numpy(), inv["ix"].to_numpy())
    assert len(wins) == 2
    (_, _, ex0, ex1), (_, _, wx0, wx1) = wins
    assert ex1 == grid.NLON - 1 and wx0 == 0
    assert (ex1 - ex0 + 1) + (wx1 - wx0 + 1) == inv["ix"].nunique()
    inv2 = grid.inventory(box(-81, 24, -80, 25), 180)
    one = grid.fetch_windows(inv2["iy"].to_numpy(), inv2["ix"].to_numpy())
    assert len(one) == 1


# ----------------------------------------------------------- boundaries
def test_split_antimeridian_polygon_becomes_one_piece():
    gdf = gpd.GeoDataFrame({"n": [1, 2]}, geometry=[box(178, 0, 180, 1), box(-180, 0, -177, 1)], crs=4326)
    b = boundaries.build(gdf, Site("X", "x", "u"), "x.shp")
    assert b.frame == 360
    assert b.whole.geom_type == "Polygon"
    assert b.whole.bounds == pytest.approx((178, 0, 183, 1), abs=1e-5)


def test_normal_polygon_keeps_180_frame_and_units():
    gdf = gpd.GeoDataFrame({"U": ["a", "b", "b"]},
                           geometry=[box(-81, 24, -80, 25), box(-79, 24, -78.5, 24.5), box(-78.5, 24, -78, 24.5)],
                           crs=4326)
    b = boundaries.build(gdf, Site("X", "x", "u", unit_field="U"), "x.shp")
    assert b.frame == 180
    assert set(b.units) == {"a", "b"}
    assert b.units["b"].area == pytest.approx(0.5)


# ---------------------------------------------------------------- stats
def test_weighted_quantiles_equal_weights():
    rng = np.random.default_rng(1)
    v = rng.normal(size=(3, 400))
    v[0, :10] = np.nan
    q = stats.weighted_quantiles(v, np.ones_like(v), [0.1, 0.5, 0.9])
    for t in range(3):
        x = v[t][np.isfinite(v[t])]
        assert q[t] == pytest.approx(np.quantile(x, [0.1, 0.5, 0.9], method="hazen"), abs=1e-9)


def test_daily_stats_weights_and_baa_fractions():
    pix = pd.DataFrame({"weight": [3.0, 1.0, 1.0]})
    vals = {
        "CRW_SST": np.array([[28.0, 30.0, np.nan]], "float32"),
        "CRW_SSTANOMALY": np.array([[0.0, 1.0, np.nan]], "float32"),
        "CRW_HOTSPOT": np.array([[0.0, 1.5, np.nan]], "float32"),
        "CRW_DHW": np.array([[0.0, 9.0, np.nan]], "float32"),
        "CRW_BAA": np.array([[0, 4, np.nan]], "float32"),
    }
    df = stats.daily_stats(np.array(["2024-08-01"], dtype="datetime64[D]"), vals, pix, "ALL")
    r = df.iloc[0]
    assert r.sst_mean == pytest.approx(28.5)          # (3*28 + 30)/4
    assert r.valid_area_frac == pytest.approx(0.8)
    assert r.n_pixels == 2
    assert r.baa_frac_0 == pytest.approx(0.75) and r.baa_frac_4 == pytest.approx(0.25)
    assert r.dhw_frac_ge8 == pytest.approx(0.25)
    assert sum(r[f"baa_frac_{k}"] for k in range(8)) == pytest.approx(1)


def test_sample_rejects_out_of_range_values():
    ds = synthetic.FakeErddap(["CRW_SST"], date(2024, 1, 5)).fetch(date(2024, 1, 1), date(2024, 1, 2), (2290, 2292, 1980, 1982))
    ds["CRW_SST"][0, 0, 0] = 99
    pix = pd.DataFrame({"iy": [2290], "ix": [1980]})
    with pytest.raises(stats.DataQualityError):
        stats.sample([ds], pix, ["CRW_SST"])


# ---------------------------------------------------------- monthly/clim
def test_monthly_completeness_and_climatology():
    days = pd.date_range("1991-01-01", "2020-12-31", freq="D")
    d = pd.DataFrame({"date": days.strftime("%Y-%m-%d"), "series": "ALL", "n_pixels": 5})
    for c in stats.DAILY_COLUMNS[3:]:
        d[c] = 0.0
    d["sst_mean"] = 25 + days.month.to_numpy() / 10
    d = d[d["date"] != "2000-02-10"]
    mon = aggregate.monthly(d)
    assert mon.loc[mon.month == "2000-02", "complete_month"].item() == 0
    assert mon.loc[mon.month == "2000-03", "complete_month"].item() == 1
    clim = aggregate.climatology(mon, (1991, 2020), 25)
    feb = clim[clim.moy == 2].iloc[0]
    assert feb.n_years == 29 and feb.published == 1
    out = aggregate.apply_anomaly(mon, clim)
    assert np.isnan(out.loc[out.month == "2000-02", "sst_anom"].item())
    assert out.loc[out.month == "2005-07", "sst_anom"].item() == pytest.approx(0, abs=1e-9)


# ------------------------------------------------------------ stations
STATION = """Name:
Florida Keys

Polygon Middle Longitude:
-81.6250

Polygon Middle Latitude:
24.7500

Averaged Maximum Monthly Mean:
29.6264

Averaged Monthly Mean (Jan-Dec):
23.4166 23.1889 23.5492 24.6089 26.4747 28.3325 29.3254 29.6264 29.1674 27.7384 26.0846 24.4925

YYYY MM DD SST_MIN SST_MAX SST@90th_HS SSTA@90th_HS 90th_HS>0 DHW_from_90th_HS>1 BAA_7day_max
2023 08 01 29.4100 31.1500 30.9600      1.5113       1.3000    6.0000            3
2023 08 02 29.1200 31.1300 30.9500      1.4029       1.3000    6.5000            3
2023 08 04 29.9900 31.2100 30.9800      1.4281       1.3000    7.0000            3
2023 08 05 29.9900 31.2100 30.98
"""


def test_station_parse_and_monthly():
    daily, meta = stations.parse(STATION, "Florida Keys")
    assert meta["mmm"] == pytest.approx(29.6264) and len(meta["monthly_means"]) == 12
    assert meta.get("dropped_partial_last_line")
    assert len(daily) == 3
    assert [d.isoformat() for d in stations.missing_dates(daily)] == ["2023-08-03"]
    mon = stations.monthly(daily)
    assert mon.iloc[0].complete_month == 0 and mon.iloc[0].dhw_max == 7 and mon.iloc[0].days_alert1_plus == 3
    with pytest.raises(ValueError):
        stations.parse(STATION, "Samoas")


# ------------------------------------------------------------- pipeline
@pytest.fixture()
def project(tmp_path):
    (tmp_path / "config").mkdir()
    (tmp_path / "config" / "sanctuaries.toml").write_text(synthetic.DEMO_CONFIG.format(start="2022-12-01"))
    cfg = config.load(tmp_path / "config" / "sanctuaries.toml", root=tmp_path)
    shapes = synthetic.demo_boundaries()
    # Add a unit that sits entirely on a land-masked island -> must borrow a water pixel.
    shapes["DEMOA"] = pd.concat([shapes["DEMOA"], gpd.GeoDataFrame(
        {"UNIT": ["On island"]}, geometry=[Point(-80.0, 24.7).buffer(0.02)], crs=4326)], ignore_index=True)
    for code, gdf in shapes.items():
        p = cfg.cache_dir / "boundaries" / f"{code.lower()}.zip"
        p.parent.mkdir(parents=True, exist_ok=True)
        synthetic.write_boundary_zip(p, gdf, f"{code.lower()}_py")
    return cfg


def test_pipeline_end_to_end_incremental(project):
    cfg = project
    gap = date(2023, 2, 10)
    client = synthetic.FakeErddap(cfg.variables, latest=date(2023, 3, 15), islands=synthetic.DEMO_ISLANDS, gaps={gap})
    log = []
    for site in cfg.select(None):
        pipeline.update_site(cfg, site, client, log=log.append)
    a = pd.read_csv(cfg.data_dir / "demoa" / "daily.csv")
    assert set(a.series) == {"ALL", "Main area", "Tiny bank", "On island"}
    assert a["date"].min() == "2022-12-01" and a["date"].max() == "2023-03-15"
    assert "2023-02-10" not in set(a["date"])
    pix = pd.read_csv(cfg.data_dir / "demoa" / "pixels.csv")
    isl = pix[pix.series == "On island"]
    assert len(isl) == 1 and bool(isl.fallback.iloc[0])
    assert any("On island" in m and "nearest" in m for m in log)

    mon = pd.read_csv(cfg.data_dir / "demoa" / "monthly.csv")
    allm = mon[mon.series == "ALL"].set_index("month")
    assert allm.loc["2023-02", "complete_month"] == 0 and allm.loc["2023-01", "complete_month"] == 1
    assert allm.loc["2023-03", "complete_month"] == 0           # month in progress

    # Antimeridian site: pixels on both sides of 180, frame stays 0-360.
    bp = pd.read_csv(cfg.data_dir / "demob" / "pixels.csv")
    assert bp.lon.min() > 178 and bp.lon.max() > 180
    assert len(client.requests) and any(w[2] == 0 for _, _, w, _ in client.requests)

    # Incremental: a later run only re-fetches the lookback window.
    client.requests.clear()
    client._latest = date(2023, 3, 20)
    client.gaps.clear()
    pipeline.update_site(cfg, cfg.sites["DEMOA"], client, log=lambda *_: None)
    starts = {r[0] for r in client.requests if r[3] != ("CRW_SST",)}
    assert starts == {date(2023, 3, 6)}                          # 15 Mar - 10 + 1
    a2 = pd.read_csv(cfg.data_dir / "demoa" / "daily.csv")
    assert a2["date"].max() == "2023-03-20"
    assert not a2.duplicated(["series", "date"]).any()
    assert "2023-02-10" not in set(a2["date"])                   # outside lookback, still a gap

    # Ranged repair fills the gap.
    pipeline.update_site(cfg, cfg.sites["DEMOA"], client, start=date(2023, 2, 1), end=date(2023, 2, 28),
                         log=lambda *_: None)
    a3 = pd.read_csv(cfg.data_dir / "demoa" / "daily.csv")
    assert "2023-02-10" in set(a3["date"]) and a3["date"].max() == "2023-03-20"

    m = pipeline.write_manifest(cfg)
    assert {s["code"] for s in m["sites"]} == {"DEMOA", "DEMOB"}


def test_boundary_change_discards_history(project):
    cfg = project
    client = synthetic.FakeErddap(cfg.variables, latest=date(2023, 1, 5), islands=synthetic.DEMO_ISLANDS)
    site = cfg.sites["DEMOB"]
    pipeline.update_site(cfg, site, client, log=lambda *_: None)
    gdf = gpd.GeoDataFrame({"NAME": ["x"]}, geometry=[box(179.0, 25.0, 181.0, 26.0)], crs=4326)
    synthetic.write_boundary_zip(cfg.cache_dir / "boundaries" / "demob.zip", gdf, "demob_py")
    msgs = []
    pipeline.update_site(cfg, site, client, log=msgs.append)
    assert any("discarding" in m for m in msgs)
    d = pd.read_csv(cfg.data_dir / "demob" / "daily.csv")
    assert d["date"].min() == "2022-12-01"
    assert d["n_pixels"].max() <= 40 * 20
