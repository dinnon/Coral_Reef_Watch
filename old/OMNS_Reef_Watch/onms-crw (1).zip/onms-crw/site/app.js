'use strict';
/* Sanctuary Reef Heat viewer. Reads the pipeline's data/ folder; no build step. */

const BAA = [
  {k:0, label:'No Stress', color:'#c9e9f6'},
  {k:1, label:'Watch',     color:'#fff200'},
  {k:2, label:'Warning',   color:'#fbad1a'},
  {k:3, label:'Alert 1',   color:'#ef1c24'},
  {k:4, label:'Alert 2',   color:'#9b0f14'},
  {k:5, label:'Alert 3',   color:'#5c0a3e'},
  {k:6, label:'Alert 4',   color:'#3d0a5c'},
  {k:7, label:'Alert 5',   color:'#1c0533'},
];
const $ = id => document.getElementById(id);
const NS = 'http://www.w3.org/2000/svg';
const S = {manifest:null, base:null, site:null, series:'ALL', span:'365', cache:{}, map:null, layers:[]};

/* ------------------------------------------------------------------ data */
function parseCSV(text){
  const rows=[]; let row=[], cur='', q=false;
  text=text.replace(/^﻿/,'');
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(q){ if(c==='"'){ if(text[i+1]==='"'){cur+='"';i++} else q=false } else cur+=c; }
    else if(c==='"') q=true;
    else if(c===','){row.push(cur);cur=''}
    else if(c==='\n'){row.push(cur);rows.push(row);row=[];cur=''}
    else if(c!=='\r') cur+=c;
  }
  if(cur!==''||row.length){row.push(cur);rows.push(row)}
  const head=rows.shift()||[];
  return rows.filter(r=>r.length===head.length).map(r=>{
    const o={}; head.forEach((h,i)=>{const v=r[i]; o[h]= v===''?null:(isNaN(+v)||/^\d{4}-\d{2}(-\d{2})?$/.test(v)||h==='series')?v:+v}); return o;
  });
}
async function fetchText(path){
  const bases = S.base ? [S.base] : (/\/site\/?/.test(location.pathname) ? ['../data/','data/'] : ['data/','../data/']);
  let last;
  for(const b of bases){
    try{ const r=await fetch(b+path,{cache:'no-cache'}); if(r.ok){S.base=b; return await r.text()} last=`HTTP ${r.status}` }
    catch(e){ last=e.message }
  }
  throw new Error(`${path}: ${last}`);
}
async function load(path, kind='csv'){
  if(S.cache[path]!==undefined) return S.cache[path];
  let v=null;
  try{ const t=await fetchText(path); v = kind==='json'?JSON.parse(t):parseCSV(t) }catch(e){ v=null }
  return S.cache[path]=v;
}

/* --------------------------------------------------------------- helpers */
const fmt=(v,d=1)=>v==null||!isFinite(v)?'—':(+v).toFixed(d);
const pct=v=>v==null||!isFinite(v)?'—':Math.round(v*100)+'%';
const dayDate=s=>new Date(s+'T00:00:00Z');
const monDate=s=>new Date(s+'-15T00:00:00Z');
function el(tag,attrs={},parent){const e=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(parent)parent.append(e);return e}
function txt(parent,x,y,s,attrs={}){const t=el('text',{x,y,class:'ax',...attrs},parent);t.textContent=s;return t}
function baaOf(v){return BAA[Math.max(0,Math.min(7,Math.round(v??0)))]}
function readable(bg){const c=bg.replace('#','');const [r,g,b]=[0,2,4].map(i=>parseInt(c.substr(i,2),16));return (r*299+g*587+b*114)/1000>140?'#111':'#fff'}

/* ----------------------------------------------------------------- chart */
function chart(svg, opts){
  // opts: {x:[Date], layers:[{type:'line'|'band'|'bars'|'stack', ...}], y:[lo,hi]?, zero, thresholds, unit, digits, tip:i=>[lines]}
  svg.replaceChildren();
  const vb=svg.viewBox.baseVal, W=vb.width, H=vb.height, L=46, R=10, T=8, B=24;
  const xs=opts.x;
  if(!xs.length){ txt(svg,W/2,H/2,'No data for this range',{class:'empty','text-anchor':'middle'}); return }
  const t0=+xs[0], t1=+xs[xs.length-1]||t0+1;
  let lo=Infinity, hi=-Infinity;
  for(const l of opts.layers){ for(const arr of (l.lo?[l.lo,l.hi]:l.stack?[l.stack.reduce((a,s)=>a.map((v,i)=>v+(s[i]||0)),xs.map(()=>0))]:[l.y])){ for(const v of arr) if(v!=null&&isFinite(v)){lo=Math.min(lo,v);hi=Math.max(hi,v)} } }
  if(opts.y){ [lo,hi]=[Math.min(opts.y[0],lo),Math.max(opts.y[1],hi)] }
  for(const t of opts.thresholds||[]) if(hi>=t*0.6) hi=Math.max(hi,t);
  if(opts.zero){lo=Math.min(lo,0);hi=Math.max(hi,0)}
  if(!isFinite(lo)){ txt(svg,W/2,H/2,'No data for this range',{class:'empty','text-anchor':'middle'}); return }
  if(hi-lo<1e-6){hi+=.5;lo-=.5}
  const pad=(hi-lo)*.06; if(!opts.y||lo<opts.y[0]) lo-=opts.zero&&lo===0?0:pad; hi+=pad;
  const X=t=>L+(W-L-R)*(xs.length===1?.5:(+t-t0)/(t1-t0)), Y=v=>T+(H-T-B)*(hi-v)/(hi-lo);
  // grid + y axis
  const step=niceStep((hi-lo)/4);
  for(let v=Math.ceil(lo/step)*step; v<=hi+1e-9; v+=step){ el('line',{x1:L,x2:W-R,y1:Y(v),y2:Y(v),class:'gl'},svg); txt(svg,L-6,Y(v)+3.5,(+v.toFixed(6)).toString()+(opts.unit||''),{'text-anchor':'end'}) }
  // x axis ticks
  const years=(t1-t0)/3.156e10;
  const ticks=[]; const d0=new Date(t0), d1=new Date(t1);
  if(years>3){ const st=years>20?5:years>8?2:1; for(let y=Math.ceil(d0.getUTCFullYear()/st)*st;y<=d1.getUTCFullYear();y+=st) ticks.push([Date.UTC(y,0,1),String(y)]) }
  else { for(let d=new Date(Date.UTC(d0.getUTCFullYear(),d0.getUTCMonth()+1,1)); +d<=t1; d=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+(years>1.5?3:2),1))) ticks.push([+d,d.toLocaleString('en',{month:'short',timeZone:'UTC'})+(d.getUTCMonth()===0||ticks.length===0?' '+d.getUTCFullYear():'')]) }
  for(const [t,s] of ticks){ if(t<t0||t>t1)continue; txt(svg,X(t),H-6,s,{'text-anchor':'middle'}) }
  if(opts.zero) el('line',{x1:L,x2:W-R,y1:Y(0),y2:Y(0),class:'zero'},svg);
  for(const t of opts.thresholds||[]) if(t<=hi) { el('line',{x1:L,x2:W-R,y1:Y(t),y2:Y(t),class:'thr'},svg) }
  const bw=Math.max(1,(W-L-R)/xs.length*0.8);
  for(const l of opts.layers){
    if(l.type==='band'){ let d='',seg=[]; const flush=()=>{ if(seg.length>1){ d+='M'+seg.map(i=>X(xs[i])+' '+Y(l.hi[i])).join('L')+'L'+seg.slice().reverse().map(i=>X(xs[i])+' '+Y(l.lo[i])).join('L')+'Z' } seg=[] };
      xs.forEach((_,i)=>{ if(l.lo[i]==null||l.hi[i]==null) flush(); else seg.push(i) }); flush(); el('path',{d,class:'band'},svg) }
    else if(l.type==='line'){ let d='',open=false; xs.forEach((x,i)=>{const v=l.y[i]; if(v==null||!isFinite(v)){open=false;return} d+=(open?'L':'M')+X(x).toFixed(1)+' '+Y(v).toFixed(1); open=true}); el('path',{d,class:l.cls||'ln'},svg) }
    else if(l.type==='bars'){ xs.forEach((x,i)=>{const v=l.y[i]; if(v==null||!isFinite(v))return; const y0=Y(Math.max(0,lo>0?lo:0)), y1=Y(v); el('rect',{x:X(x)-bw/2,y:Math.min(y0,y1),width:bw,height:Math.max(.5,Math.abs(y1-y0)),fill:l.color?l.color(v,i):'var(--accent)'},svg) }) }
    else if(l.type==='stack'){ const base=xs.map(()=>0); l.stack.forEach((s,j)=>{ let d=''; const top=s.map((v,i)=>base[i]+(v||0));
        d='M'+xs.map((x,i)=>X(x)+' '+Y(top[i])).join('L')+'L'+xs.map((x,i)=>X(x)+' '+Y(base[i])).reverse().join('L')+'Z';
        el('path',{d,fill:l.colors[j],stroke:'none'},svg); top.forEach((v,i)=>base[i]=v) }) }
  }
  // hover
  const cur=el('line',{x1:-9,x2:-9,y1:T,y2:H-B,class:'cursor'},svg);
  const hit=el('rect',{x:L,y:T,width:W-L-R,height:H-T-B,fill:'transparent'},svg);
  const tip=$('tip'), host=svg.closest('.charts');
  hit.addEventListener('mousemove',e=>{
    const box=svg.getBoundingClientRect(), lx=(e.clientX-box.left)/box.width*W, t=t0+(lx-L)/(W-L-R)*(t1-t0);
    let i=bisect(xs,t); cur.setAttribute('x1',X(xs[i])); cur.setAttribute('x2',X(xs[i]));
    tip.innerHTML=opts.tip(i).join('<br>'); tip.style.display='block';
    const hb=host.getBoundingClientRect(); let left=e.clientX-hb.left+12; if(left+tip.offsetWidth>hb.width-4) left=e.clientX-hb.left-tip.offsetWidth-12;
    tip.style.left=left+'px'; tip.style.top=(e.clientY-hb.top-tip.offsetHeight-10)+'px';
  });
  hit.addEventListener('mouseleave',()=>{tip.style.display='none';cur.setAttribute('x1',-9);cur.setAttribute('x2',-9)});
}
function climOnDay(C,date){
  // Monthly climatology placed mid-month and linearly interpolated, so the daily view gets a smooth seasonal curve.
  if(C.size<12) return null;
  const d=dayDate(date), y=d.getUTCFullYear(), m=d.getUTCMonth();
  const mid=(yy,mm)=>Date.UTC(yy,mm,15);
  const [ya,ma]= d.getUTCDate()>=15?[y,m]:(m===0?[y-1,11]:[y,m-1]);
  const [yb,mb]= ma===11?[ya+1,0]:[ya,ma+1];
  const f=(+d-mid(ya,ma))/(mid(yb,mb)-mid(ya,ma));
  return C.get(ma+1)*(1-f)+C.get(mb+1)*f;
}
function niceStep(raw){const p=Math.pow(10,Math.floor(Math.log10(raw||1))),n=raw/p;return (n<1.5?1:n<3?2:n<7?5:10)*p}
function bisect(xs,t){let a=0,b=xs.length-1;while(b-a>1){const m=(a+b)>>1;if(+xs[m]<t)a=m;else b=m}return Math.abs(+xs[a]-t)<=Math.abs(+xs[b]-t)?a:b}

/* ------------------------------------------------------------------- map */
function initMap(){
  S.map=L.map('map',{zoomSnap:.25,worldCopyJump:false,attributionControl:true}).setView([20,-120],3);
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Base/MapServer/tile/{z}/{y}/{x}',
    {maxZoom:13,attribution:'Basemap © Esri, GEBCO, NOAA, Garmin, HERE · Data: NOAA Coral Reef Watch, NOAA ONMS'}).addTo(S.map);
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Reference/MapServer/tile/{z}/{y}/{x}',{maxZoom:13,pane:'shadowPane'}).addTo(S.map);
  S.map.on('mousemove',e=>{
    const p=S.pixelLookup; if(!p) return;
    const lat=Math.round((e.latlng.lat-0.025)/0.05)*0.05+0.025, lon=Math.round((normLon(e.latlng.lng,p.frame)-0.025)/0.05)*0.05+0.025;
    const r=p.map.get(key(lat,lon));
    S.map.getContainer().title = r ? `${r.lat.toFixed(3)}, ${(+r.lon>180?r.lon-360:+r.lon).toFixed(3)} · SST ${fmt(r.sst,2)} °C · anomaly ${fmt(r.ssta,2)} · DHW ${fmt(r.dhw,1)} · ${baaOf(r.baa).label}` : '';
  });
}
function normLon(x,frame){ if(frame===360){ x=((x%360)+360)%360 } else { x=((x+180)%360+360)%360-180 } return x }
const key=(lat,lon)=>Math.round(lat*1000)+':'+Math.round(lon*1000);

function colourFor(v, r){
  if(r==null||!isFinite(r)) return null;
  if(v==='baa') return BAA[Math.max(0,Math.min(7,Math.round(r)))].color;
  if(v==='dhw') return ramp(['#e9f3f8','#ffe08a','#f7a13b','#e5432f','#9b0f14','#4a0b3f'], Math.min(1, r/16));
  if(v==='ssta') return ramp(['#2c5fa8','#8fb8e0','#f4f4f4','#f2a07b','#c0332b'], (Math.max(-3,Math.min(3,r))+3)/6);
  return ramp(['#1e3f8a','#2f8ec4','#7fd0c4','#f3e27a','#f08a3c','#b8232b'], (r-S.sstRange[0])/(S.sstRange[1]-S.sstRange[0]||1));
}
function ramp(stops,t){ t=Math.max(0,Math.min(1,t)); const n=stops.length-1, i=Math.min(n-1,Math.floor(t*n)), f=t*n-i;
  const a=hex(stops[i]), b=hex(stops[i+1]); return `rgb(${a.map((c,j)=>Math.round(c+(b[j]-c)*f)).join(',')})` }
function hex(h){h=h.replace('#','');return [0,2,4].map(i=>parseInt(h.substr(i,2),16))}

async function drawMap(){
  const site=S.site, slug=site.code.toLowerCase();
  for(const l of S.layers) S.map.removeLayer(l); S.layers=[];
  const [geo,pixels,latest]=await Promise.all([load(`${slug}/boundary.geojson`,'json'),load(`${slug}/pixels.csv`),load(`${slug}/latest_pixels.csv`)]);
  const frame=geo?.frame||180;
  let bounds=null;
  if(geo){
    const sel=L.geoJSON(geo,{filter:f=>f.properties.series===S.series||(S.series!=='ALL'&&f.properties.series==='ALL'),
      style:f=>({color:f.properties.series===S.series?'#0b3b4a':'#53707a',weight:f.properties.series===S.series?2.2:1,dashArray:f.properties.series===S.series?null:'4 4',fill:false})});
    sel.addTo(S.map); S.layers.push(sel);
    const cur=L.geoJSON({type:'FeatureCollection',features:geo.features.filter(f=>f.properties.series===S.series)});
    bounds=cur.getBounds().isValid()?cur.getBounds():sel.getBounds();
  }
  const v=$('mapVar').value;
  const inSeries=new Set((pixels||[]).filter(p=>p.series===S.series).map(p=>key(p.lat,p.lon)));
  const fallback=(pixels||[]).filter(p=>p.series===S.series&&String(p.fallback)==='True');
  const rows=(latest||[]).filter(r=>inSeries.has(key(r.lat,r.lon)));
  S.pixelLookup={frame,map:new Map(rows.map(r=>[key(r.lat,r.lon),r]))};
  const ssts=rows.map(r=>r.sst).filter(x=>x!=null).sort((a,b)=>a-b);
  S.sstRange=ssts.length?[ssts[Math.floor(ssts.length*.02)],ssts[Math.floor(ssts.length*.98)]]:[20,30];
  if(rows.length){
    const lats=rows.map(r=>r.lat), lons=rows.map(r=>r.lon);
    const la0=Math.min(...lats),la1=Math.max(...lats),lo0=Math.min(...lons),lo1=Math.max(...lons);
    const nx=Math.round((lo1-lo0)/.05)+1, ny=Math.round((la1-la0)/.05)+1;
    const c=document.createElement('canvas'); c.width=nx; c.height=ny; const g=c.getContext('2d');
    for(const r of rows){ const col=colourFor(v,r[v]); if(!col)continue; g.fillStyle=col; g.fillRect(Math.round((r.lon-lo0)/.05), Math.round((la1-r.lat)/.05),1,1) }
    const ov=L.imageOverlay(c.toDataURL(),[[la0-.025,lo0-.025],[la1+.025,lo1+.025]],{opacity:.82,className:'pix'});
    ov.addTo(S.map); S.layers.push(ov);
    ov.bringToBack();
  }
  for(const f of fallback){ const m=L.circleMarker([f.lat,f.lon],{radius:6,color:'#c0662b',weight:2,fill:false}).bindTooltip('Nearest water pixel used for this unit'); m.addTo(S.map); S.layers.push(m) }
  if(bounds) S.map.fitBounds(bounds,{padding:[18,18]});
  legend(v);
  const meta=site.pixels?.[S.series]||{};
  $('pixelNote').textContent = rows.length
    ? `${meta.water??rows.length} CRW water pixels (5 km) inside or touching the boundary · values for ${rows[0].date} · hover the map for pixel values`
    + (meta.fallback_km!=null?` · this unit has no water pixel of its own; using the nearest, ${meta.fallback_km} km away`:'')
    : 'No pixel snapshot available yet.';
}
function legend(v){
  const box=$('legend');
  if(v==='baa'){ box.innerHTML=BAA.map(b=>`<span><i class="sw" style="background:${b.color}"></i>${b.label}</span>`).join(''); return }
  const cfg={dhw:['0','16+ °C-wk',['#e9f3f8','#ffe08a','#f7a13b','#e5432f','#9b0f14','#4a0b3f']],
             ssta:['−3 °C','+3 °C',['#2c5fa8','#8fb8e0','#f4f4f4','#f2a07b','#c0332b']],
             sst:[fmt(S.sstRange[0],1)+' °C',fmt(S.sstRange[1],1)+' °C',['#1e3f8a','#2f8ec4','#7fd0c4','#f3e27a','#f08a3c','#b8232b']]}[v];
  box.innerHTML=`<span>${cfg[0]}</span><i class="bar" style="background:linear-gradient(90deg,${cfg[2].join(',')})"></i><span>${cfg[1]}</span>`;
}

/* ----------------------------------------------------------------- tiles */
function tiles(daily, monthly){
  const box=$('tiles'); box.replaceChildren();
  const last=daily.at(-1);
  if(!last){ box.textContent='No data yet.'; return }
  $('asOf').textContent='Latest satellite day: '+last.date;
  const lastMon=monthly.filter(m=>m.complete_month===1&&m.sst_anom!=null).at(-1);
  const alert1=[3,4,5,6,7].reduce((a,k)=>a+(last['baa_frac_'+k]||0),0);
  const items=[
    ['SST, area mean', fmt(last.sst_mean,2)+' °C', `range ${fmt(last.sst_p10,1)}–${fmt(last.sst_p90,1)} (p10–p90)`],
    ['SST anomaly (CRW, daily)', (last.ssta_mean>0?'+':'')+fmt(last.ssta_mean,2)+' °C', 'vs CRW 1985–2012 daily climatology'],
    lastMon?['Monthly anomaly', (lastMon.sst_anom>0?'+':'')+fmt(lastMon.sst_anom,2)+' °C', `${lastMon.month} vs ${S.manifest.climatology}`]:null,
  ];
  if(S.site.coral){
    items.push(['DHW, max pixel', fmt(last.dhw_max,1), `area mean ${fmt(last.dhw_mean,1)} · p90 ${fmt(last.dhw_p90,1)} °C-weeks`]);
    items.push(['Highest alert', null, `${pct(alert1)} of area at Alert 1 or higher`, baaOf(last.baa_max)]);
  }
  items.push(['Valid area', pct(last.valid_area_frac), `${last.n_pixels} pixels reporting`]);
  for(const it of items.filter(Boolean)){
    const d=document.createElement('div'); d.className='tile';
    d.innerHTML=`<div class="k">${it[0]}</div>`+(it[3]?`<span class="chip" style="background:${it[3].color};color:${readable(it[3].color)}">${it[3].label}</span>`:`<div class="v">${it[1]}</div>`)+`<div class="s">${it[2]}</div>`;
    box.append(d);
  }
}

/* ---------------------------------------------------------------- charts */
async function drawCharts(){
  const slug=S.site.code.toLowerCase();
  const [daily,monthly,clim]=await Promise.all([load(`${slug}/recent_daily.csv`),load(`${slug}/monthly.csv`),load(`${slug}/climatology.csv`)]);
  const D=(daily||[]).filter(r=>r.series===S.series), M=(monthly||[]).filter(r=>r.series===S.series);
  const C=new Map((clim||[]).filter(r=>r.series===S.series&&r.published===1).map(r=>[r.moy,r.sst_clim]));
  tiles(D,M);
  const showStn=$('showStation').checked && S.site.has_station && S.series==='ALL';
  let stD=null, stM=null;
  if(showStn){ [stD,stM]=await Promise.all([load(`${slug}/station_daily.csv`),load(`${slug}/station_monthly.csv`)]) }
  const sName=S.site.station?.name;
  $('stnNote').hidden=!showStn;

  if(S.span==='all'){
    const x=M.map(r=>monDate(r.month));
    const ok=r=>r.complete_month===1;
    const v=(f)=>M.map(r=>ok(r)?r[f]:null);
    const climY=M.map(r=>C.get(+r.month.slice(5,7))??null);
    const stMap=new Map((stM||[]).filter(r=>r.complete_month===1).map(r=>[r.month,r]));
    const layers=[{type:'band',lo:v('sst_p10'),hi:v('sst_p90')},{type:'line',y:climY,cls:'clim'},{type:'line',y:v('sst_mean')}];
    if(showStn) layers.push({type:'line',y:M.map(r=>stMap.get(r.month)?.sst_at_hs90_mean??null),cls:'stn'});
    chart($('cSST'),{x,layers,unit:'°',tip:i=>{const r=M[i];return [`<b>${r.month}</b>${ok(r)?'':' · incomplete ('+r.days_reported+'/'+r.days_in_month+' d)'}`,`Mean ${fmt(r.sst_mean,2)} °C (p10 ${fmt(r.sst_p10,1)}, p90 ${fmt(r.sst_p90,1)})`,`Climatology ${fmt(climY[i],2)} °C`].concat(showStn?[`${sName} station ${fmt(stMap.get(r.month)?.sst_at_hs90_mean,2)} °C`]:[])}});
    $('climNote').hidden=false;
    $('anomNote').textContent=`monthly mean minus this area's ${S.manifest.climatology} climatology (complete months only)`;
    chart($('cAnom'),{x,zero:true,unit:'°',layers:[{type:'bars',y:v('sst_anom'),color:a=>a>=0?'var(--pos)':'var(--neg)'}],
      tip:i=>[`<b>${M[i].month}</b>`,`Anomaly ${M[i].sst_anom==null?'—':(M[i].sst_anom>0?'+':'')+fmt(M[i].sst_anom,2)+' °C'}`]});
    if(S.site.coral){
      const dl=[{type:'line',y:M.map(r=>r.dhw_max),cls:'ln thin'},{type:'line',y:M.map(r=>r.dhw_mean_max)}];
      if(showStn) dl.push({type:'line',y:M.map(r=>stMap.get(r.month)?.dhw_max??null),cls:'stn'});
      chart($('cDHW'),{x,y:[0,4],thresholds:[4,8],layers:dl,tip:i=>[`<b>${M[i].month}</b>`,`Max pixel ${fmt(M[i].dhw_max,1)}`,`Peak area mean ${fmt(M[i].dhw_mean_max,1)}`].concat(showStn?[`Station ${fmt(stMap.get(M[i].month)?.dhw_max,1)}`]:[])});
      $('baaNote').textContent='peak share of area at Alert 1+ (and Alert 2+) during each month';
      chart($('cBAA'),{x,y:[0,1],layers:[{type:'bars',y:M.map(r=>r.peak_frac_alert1_plus),color:()=>BAA[3].color},{type:'bars',y:M.map(r=>r.peak_frac_alert2_plus),color:()=>BAA[4].color}],
        tip:i=>[`<b>${M[i].month}</b>`,`Peak area Alert 1+ ${pct(M[i].peak_frac_alert1_plus)}`,`Peak area Alert 2+ ${pct(M[i].peak_frac_alert2_plus)}`,`${M[i].days_alert1_plus} day(s) with any Alert 1+ pixel`,`Highest level ${baaOf(M[i].baa_max).label}`]});
      $('baaLegend').innerHTML=[3,4].map(k=>`<span><i class="sw" style="background:${BAA[k].color}"></i>${BAA[k].label}${k===3?'+':'+'}</span>`).join('');
    }
  } else {
    const n=+S.span, R=D.slice(-n), x=R.map(r=>dayDate(r.date));
    const stMap=new Map((stD||[]).map(r=>[r.date,r]));
    const climD=R.map(r=>climOnDay(C,r.date));
    const layers=[{type:'band',lo:R.map(r=>r.sst_p10),hi:R.map(r=>r.sst_p90)},{type:'line',y:climD,cls:'clim'},{type:'line',y:R.map(r=>r.sst_mean)}];
    if(showStn) layers.push({type:'line',y:R.map(r=>stMap.get(r.date)?.sst_at_hs90??null),cls:'stn'});
    chart($('cSST'),{x,layers,unit:'°',tip:i=>{const r=R[i];return [`<b>${r.date}</b>`,`Mean ${fmt(r.sst_mean,2)} °C (p10 ${fmt(r.sst_p10,1)}, p90 ${fmt(r.sst_p90,1)})`,`Min ${fmt(r.sst_min,1)} · max ${fmt(r.sst_max,1)}`,`Climatology ${fmt(climD[i],2)} °C`].concat(showStn?[`${sName} station ${fmt(stMap.get(r.date)?.sst_at_hs90,2)} °C`]:[])}});
    $('climNote').hidden=false;
    $('anomNote').textContent='NOAA CRW pixel SST anomaly, area-weighted (CRW 1985–2012 daily climatology)';
    chart($('cAnom'),{x,zero:true,unit:'°',layers:[{type:'bars',y:R.map(r=>r.ssta_mean),color:a=>a>=0?'var(--pos)':'var(--neg)'}],tip:i=>[`<b>${R[i].date}</b>`,`Anomaly ${(R[i].ssta_mean>0?'+':'')+fmt(R[i].ssta_mean,2)} °C (p90 ${fmt(R[i].ssta_p90,2)})`]});
    if(S.site.coral){
      const dl=[{type:'line',y:R.map(r=>r.dhw_max),cls:'ln thin'},{type:'line',y:R.map(r=>r.dhw_p90),cls:'ln p90'},{type:'line',y:R.map(r=>r.dhw_mean)}];
      if(showStn) dl.push({type:'line',y:R.map(r=>stMap.get(r.date)?.dhw_from_hs90??null),cls:'stn'});
      chart($('cDHW'),{x,y:[0,4],thresholds:[4,8],layers:dl,tip:i=>[`<b>${R[i].date}</b>`,`Max ${fmt(R[i].dhw_max,1)} · p90 ${fmt(R[i].dhw_p90,1)} · mean ${fmt(R[i].dhw_mean,1)}`,`Area ≥4: ${pct(R[i].dhw_frac_ge4)} · ≥8: ${pct(R[i].dhw_frac_ge8)}`].concat(showStn?[`Station ${fmt(stMap.get(R[i].date)?.dhw_from_hs90,1)}`]:[])});
      $('baaNote').textContent='share of area at each daily alert level';
      const levels=[1,2,3,4,5,6,7];
      chart($('cBAA'),{x,y:[0,1],layers:[{type:'stack',stack:levels.map(k=>R.map(r=>r['baa_frac_'+k]||0)),colors:levels.map(k=>BAA[k].color)}],
        tip:i=>[`<b>${R[i].date}</b>`].concat(BAA.filter(b=>(R[i]['baa_frac_'+b.k]||0)>0.0005).map(b=>`${b.label}: ${pct(R[i]['baa_frac_'+b.k])}`))});
      $('baaLegend').innerHTML=levels.map(k=>`<span><i class="sw" style="background:${BAA[k].color}"></i>${BAA[k].label}</span>`).join('');
    }
  }
  const slugp=S.base+slug;
  $('downloads').innerHTML='Download: '+[['daily.csv','Daily (full)'],['monthly.csv','Monthly'],['climatology.csv','Climatology'],['pixels.csv','Pixel inventory'],['boundary.geojson','Boundary']]
    .map(([f,l])=>`<a href="${slugp}/${f}" download>${l}</a>`).join('')+(S.site.has_station?`<a href="${slugp}/station_daily.csv" download>Station (daily)</a>`:'');
}

/* ------------------------------------------------------------------ wiring */
async function selectSite(code){
  S.site=S.manifest.sites.find(s=>s.code===code);
  const ser=$('series'); ser.replaceChildren();
  for(const s of S.site.series){ const o=document.createElement('option'); o.value=s; o.textContent=s==='ALL'?'Whole sanctuary':s; ser.append(o) }
  ser.disabled=S.site.series.length<2; S.series='ALL';
  $('siteName').textContent=S.site.name;
  document.body.classList.toggle('hidden-coral',!S.site.coral);
  $('stationToggle').hidden=!S.site.has_station;
  if(S.site.has_station) $('stationToggle').lastChild.textContent=` Compare CRW regional station (${S.site.station?.name||''})`;
  if(!S.site.coral && $('mapVar').value!=='sst' && $('mapVar').value!=='ssta') $('mapVar').value='ssta';
  [...$('mapVar').options].forEach(o=>o.hidden=!S.site.coral&&(o.value==='dhw'||o.value==='baa'));
  history.replaceState(null,'','#'+code);
  await refresh();
}
async function refresh(){ await Promise.all([drawMap(),drawCharts()]) }

async function main(){
  initMap();
  S.manifest=await load('manifest.json','json');
  if(!S.manifest||!S.manifest.sites?.length){
    $('siteName').textContent='No pipeline output found';
    $('tiles').innerHTML='Run <code>onms-crw update</code> and serve this folder next to <code>data/</code> (e.g. <code>python -m http.server</code> from the repository root, then open <code>/site/</code>).';
    return;
  }
  if(S.manifest.synthetic){ const b=$('banner'); b.hidden=false; b.textContent='SYNTHETIC DEMO DATA — generated offline to exercise the pipeline and viewer. Not NOAA observations.' }
  $('generated').textContent=`Generated ${S.manifest.generated_utc} · pipeline ${S.manifest.pipeline_version} · ${S.manifest.sources.crw}`;
  const sel=$('site');
  const groups=[['Coral reef sanctuaries',s=>s.coral],['Other sanctuaries (SST only)',s=>!s.coral]];
  for(const [label,f] of groups){ const list=S.manifest.sites.filter(f); if(!list.length)continue; const g=document.createElement('optgroup'); g.label=label;
    for(const s of list){ const o=document.createElement('option'); o.value=s.code; o.textContent=`${s.name.replace(' National Marine Sanctuary','')} (${s.code})`; g.append(o) } sel.append(g) }
  const want=location.hash.slice(1).toUpperCase();
  sel.value=S.manifest.sites.some(s=>s.code===want)?want:S.manifest.sites[0].code;
  sel.addEventListener('change',()=>selectSite(sel.value));
  $('series').addEventListener('change',e=>{S.series=e.target.value;refresh()});
  $('mapVar').addEventListener('change',drawMap);
  $('showStation').addEventListener('change',drawCharts);
  $('span').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;S.span=b.dataset.span;[...$('span').children].forEach(x=>x.setAttribute('aria-selected',x===b));drawCharts()});
  await selectSite(sel.value);
}
main();
