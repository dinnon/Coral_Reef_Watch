"""Command line: onms-crw {inspect,update,stations,summarise,manifest}."""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

from . import boundaries, config, pipeline, stations
from .erddap import Erddap

DEFAULT_CONFIG = Path("config/sanctuaries.toml")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="onms-crw", description=__doc__)
    ap.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("inspect", help="Download boundary zips and list layers/attributes")
    p.add_argument("sites", nargs="*")

    p = sub.add_parser("update", help="Incremental (or ranged) boundary-clipped update")
    p.add_argument("sites", nargs="*", help="ONMS codes; default = enabled sites")
    p.add_argument("--start", type=date.fromisoformat, help="re-fetch from this date (backfill/repair)")
    p.add_argument("--end", type=date.fromisoformat)
    p.add_argument("--refresh-boundaries", action="store_true")
    p.add_argument("--rebuild-inventory", action="store_true")
    p.add_argument("--no-stations", action="store_true")
    p.add_argument("--keep-going", action="store_true", help="continue with other sites after a failure")

    p = sub.add_parser("stations", help="Regional virtual station comparison series only")
    p.add_argument("sites", nargs="*")

    p = sub.add_parser("summarise", help="Recompute monthly/climatology from existing daily.csv")
    p.add_argument("sites", nargs="*")

    sub.add_parser("manifest", help="Rewrite data/manifest.json")

    p = sub.add_parser("demo", help="Build an offline SYNTHETIC demo project (no network)")
    p.add_argument("out", type=Path)
    p.add_argument("--start", default="1985-04-01")

    a = ap.parse_args(argv)
    if a.cmd == "demo":
        from . import synthetic
        synthetic.build_demo(a.out, start=a.start, log=lambda *_: None)
        print(f"Synthetic demo written to {a.out}/data")
        return 0

    cfg = config.load(a.config)

    if a.cmd == "inspect":
        for site in cfg.select(a.sites, include_disabled=not a.sites):
            path = boundaries.download(cfg, site)
            print(boundaries.describe(path, site))
        return 0

    if a.cmd == "stations":
        for site in cfg.select(a.sites):
            stations.update(cfg, site)
        pipeline.write_manifest(cfg)
        return 0

    if a.cmd == "summarise":
        for site in cfg.select(a.sites):
            pipeline.summarise_site(cfg, site)
        return 0

    if a.cmd == "manifest":
        pipeline.write_manifest(cfg)
        return 0

    client = Erddap(cfg.servers, cfg.dataset, cfg.variables, cfg.request_pause_s, cfg.cache_dir)
    failures = []
    for site in cfg.select(a.sites):
        try:
            pipeline.update_site(cfg, site, client, start=a.start, end=a.end,
                                 refresh_boundary=a.refresh_boundaries,
                                 rebuild_inventory=a.rebuild_inventory,
                                 with_station=not a.no_stations)
        except Exception as err:
            failures.append((site.code, err))
            print(f"!! {site.code} failed: {err}", file=sys.stderr)
            if not a.keep_going:
                break
    pipeline.write_manifest(cfg)
    if failures:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
