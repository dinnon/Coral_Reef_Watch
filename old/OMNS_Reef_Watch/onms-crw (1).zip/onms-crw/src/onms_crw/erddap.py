"""Minimal ERDDAP griddap client for the CRW 5 km daily product."""

from __future__ import annotations

import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
import tempfile

import numpy as np
import xarray as xr

from . import grid, io

MAX_CELLS_PER_REQUEST = 40_000_000   # ~160 MB of float32 across variables


def _t(d: date) -> str:
    return f"{d.isoformat()}T12:00:00Z"   # CRW daily stamps are 12:00 UTC


class Erddap:
    def __init__(self, servers, dataset: str, variables, pause_s: float = 1.0, cache: Path | None = None):
        self.servers = list(servers)
        self.dataset = dataset
        self.variables = list(variables)
        self.pause_s = pause_s
        self.cache = cache
        self.server: str | None = None
        self._lat_descending = True

    # -------------------------------------------------------------- discovery
    def latest_date(self) -> date:
        errors = []
        for server in ([self.server] if self.server else self.servers):
            url = f"{server}/griddap/{self.dataset}.csv0?time%5Blast%5D"
            try:
                text = io.get(url, timeout=60, attempts=2).decode().strip()
                self.server = server
                return datetime.fromisoformat(text.splitlines()[-1].replace("Z", "+00:00")).date()
            except io.FetchError as err:
                errors.append(str(err))
        raise io.FetchError("No ERDDAP server answered:\n  " + "\n  ".join(errors))

    # ------------------------------------------------------------------ fetch
    def _url(self, variables, d0: date, d1: date, win) -> str:
        y0, y1, x0, x1 = win
        south, north = float(grid.lat_center(y0)), float(grid.lat_center(y1))
        west, east = float(grid.lon_center(x0)), float(grid.lon_center(x1))
        lat = f"[({north:.3f}):1:({south:.3f})]" if self._lat_descending else f"[({south:.3f}):1:({north:.3f})]"
        sel = f"[({_t(d0)}):1:({_t(d1)})]{lat}[({west:.3f}):1:({east:.3f})]"
        query = ",".join(v + sel for v in variables)
        query = query.replace("[", "%5B").replace("]", "%5D").replace(":", "%3A")
        return f"{self.server}/griddap/{self.dataset}.nc?{query}"

    def fetch(self, d0: date, d1: date, win, variables=None) -> xr.Dataset:
        """Daily fields for [d0, d1] over one grid window, loaded into memory."""
        if self.server is None:
            self.latest_date()
        variables = list(variables or self.variables)
        y0, y1, x0, x1 = win
        days = (d1 - d0).days + 1
        cells = days * (y1 - y0 + 1) * (x1 - x0 + 1) * len(variables)
        if cells > MAX_CELLS_PER_REQUEST and days > 1:
            mid = d0 + timedelta(days=days // 2 - 1)
            a = self.fetch(d0, mid, win, variables)
            b = self.fetch(mid + timedelta(days=1), d1, win, variables)
            return xr.concat([a, b], dim="time")
        tmpdir = self.cache / "tmp" if self.cache else None
        if tmpdir:
            tmpdir.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(suffix=".nc", dir=tmpdir, delete=False) as fh:
            path = Path(fh.name)
        try:
            try:
                io.get(self._url(variables, d0, d1, win), stream_to=path, timeout=600)
            except io.FetchError as err:
                # Some ERDDAP builds want axis constraints in storage order; try the other one.
                if "HTTP 4" not in str(err):
                    raise
                self._lat_descending = not self._lat_descending
                io.get(self._url(variables, d0, d1, win), stream_to=path, timeout=600)
            with xr.open_dataset(path, decode_times=True, mask_and_scale=True) as ds:
                ds = ds[variables].load()
        finally:
            path.unlink(missing_ok=True)
            time.sleep(self.pause_s)
        return normalise(ds)


def normalise(ds: xr.Dataset) -> xr.Dataset:
    """Daily dates, ascending latitude, float32 data."""
    ds = ds.rename({k: v for k, v in {"lat": "latitude", "lon": "longitude"}.items() if k in ds.dims})
    times = ds["time"].values
    ds = ds.assign_coords(time=np.array(times, dtype="datetime64[D]"))
    ds = ds.sortby("latitude")
    for v in ds.data_vars:
        ds[v] = ds[v].astype("float32")
    return ds


def utc_today() -> date:
    return datetime.now(timezone.utc).date()
