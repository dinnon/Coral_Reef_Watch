"""Configuration loading."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path


@dataclass(frozen=True)
class Station:
    name: str
    file: str


@dataclass(frozen=True)
class Site:
    code: str
    name: str
    boundary_url: str
    coral: bool = True
    enabled: bool = True
    station: Station | None = None
    unit_field: str | None = None

    @property
    def slug(self) -> str:
        return self.code.lower()


@dataclass(frozen=True)
class Config:
    sites: dict[str, Site]
    start_date: date
    lookback_days: int
    climatology: tuple[int, int]
    min_baseline_years: int
    fallback_km: float
    request_pause_s: float
    servers: tuple[str, ...]
    dataset: str
    variables: tuple[str, ...]
    station_base_url: str
    root: Path = field(default=Path("."))

    @property
    def data_dir(self) -> Path:
        return self.root / "data"

    @property
    def cache_dir(self) -> Path:
        return self.root / "cache"

    def select(self, codes: list[str] | None, include_disabled: bool = False) -> list[Site]:
        if codes:
            unknown = [c for c in codes if c.upper() not in self.sites]
            if unknown:
                raise SystemExit(f"Unknown site code(s): {', '.join(unknown)}. "
                                 f"Known: {', '.join(self.sites)}")
            return [self.sites[c.upper()] for c in codes]
        return [s for s in self.sites.values() if s.enabled or include_disabled]


def load(path: Path, root: Path | None = None) -> Config:
    raw = tomllib.loads(Path(path).read_text(encoding="utf-8"))
    p, e = raw["pipeline"], raw["erddap"]
    sites = {}
    for code, s in raw["sites"].items():
        st = s.get("station")
        sites[code.upper()] = Site(
            code=code.upper(), name=s["name"], boundary_url=s["boundary_url"],
            coral=bool(s.get("coral", True)), enabled=bool(s.get("enabled", True)),
            station=Station(st["name"], st["file"]) if st else None,
            unit_field=s.get("unit_field"),
        )
    return Config(
        sites=sites,
        start_date=date.fromisoformat(p["start_date"]),
        lookback_days=int(p["lookback_days"]),
        climatology=tuple(p["climatology"]),
        min_baseline_years=int(p["min_baseline_years"]),
        fallback_km=float(p["fallback_km"]),
        request_pause_s=float(p["request_pause_s"]),
        servers=tuple(s.rstrip("/") for s in e["servers"]),
        dataset=e["dataset"],
        variables=tuple(e["variables"]),
        station_base_url=raw["stations"]["base_url"],
        root=root if root is not None else Path(path).resolve().parent.parent,
    )
