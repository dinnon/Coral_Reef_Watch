"""Orchestration: boundaries -> pixel inventory -> daily stats -> monthly/climatology -> manifest."""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd

from . import __version__, aggregate, boundaries, grid, io, stations, stats
from .config import Config, Site
from .erddap import Erddap

CHECKPOINT_EVERY = 24  # months (resumable backfills without rewriting the CSV every month)
RECENT_DAYS = 1830


# ------------------------------------------------------------------ inventory
def _pad_windows(windows, pad):
    out = []
    for y0, y1, x0, x1 in windows:
        out.append((max(0, y0 - pad), min(grid.NLAT - 1, y1 + pad),
                    max(0, x0 - pad), min(grid.NLON - 1, x1 + pad)))
    return out


def build_inventory(cfg: Config, b: boundaries.Boundary, client: Erddap, log=print):
    """Pixels for every series, restricted to CRW water pixels, with nearest-water fallback."""
    parts = []
    for name, geom in b.series().items():
        inv = grid.inventory(geom, b.frame)
        inv.insert(0, "series", name)
        parts.append(inv)
    pix = pd.concat(parts, ignore_index=True)
    if pix.empty:
        raise ValueError(f"{b.site.code}: boundary touches no CRW pixels")

    pad = int(np.ceil(cfg.fallback_km / 5.0)) + 1
    windows = _pad_windows(grid.fetch_windows(pix["iy"].to_numpy(), pix["ix"].to_numpy()), pad)
    probe_day = client.latest_date() - timedelta(days=1)
    dss = [client.fetch(probe_day, probe_day, w, variables=["CRW_SST"]) for w in windows]
    water = {}
    for ds in dss:
        giy = grid.lat_index(ds["latitude"].values)
        gix = grid.lon_index(ds["longitude"].values)
        ok = np.isfinite(ds["CRW_SST"].values[0])
        yy, xx = np.nonzero(ok)
        for a, c in zip(giy[yy], gix[xx]):
            water[(int(a), int(c))] = True
    pix["water"] = [water.get((a, c), False) for a, c in zip(pix["iy"], pix["ix"])]
    water_iy = np.array([k[0] for k in water]) if water else np.array([], int)
    water_ix = np.array([k[1] for k in water]) if water else np.array([], int)

    counts = {}
    kept = []
    for name, geom in b.series().items():
        s = pix[pix["series"] == name]
        n_touch = len(s)
        s = s[s["water"]].drop(columns="water")
        if s.empty:
            # Unit too small or too close to shore for a 5 km water pixel: borrow the nearest.
            rp = geom.representative_point()
            lat0, lon0 = rp.y, rp.x
            if len(water_iy) == 0:
                raise ValueError(f"{b.site.code}/{name}: no water pixels in probe window")
            dist = grid.haversine_km(lat0, lon0, grid.lat_center(water_iy), grid.lon_center(water_ix))
            k = int(np.argmin(dist))
            if dist[k] > cfg.fallback_km:
                log(f"  ! {b.site.code}/{name}: nearest water pixel is {dist[k]:.1f} km away; series left empty")
                counts[name] = {"touching": n_touch, "water": 0, "fallback_km": None}
                continue
            lat = float(grid.lat_center(water_iy[k]))
            lon = float(grid.lon_center(water_ix[k]))
            if b.frame == 360 and lon < 0:
                lon += 360
            s = pd.DataFrame([{"series": name, "lat": round(lat, 3), "lon": round(lon, 3),
                               "iy": int(water_iy[k]), "ix": int(water_ix[k]), "cover": 0.0,
                               "center_inside": False, "weight": float(np.cos(np.deg2rad(lat))),
                               "fallback": True}])
            counts[name] = {"touching": n_touch, "water": 0, "fallback_km": round(float(dist[k]), 2)}
            log(f"  {b.site.code}/{name}: no water pixel inside; using nearest at {dist[k]:.1f} km")
        else:
            counts[name] = {"touching": n_touch, "water": len(s), "fallback_km": None}
        kept.append(s)
    pix = pd.concat(kept, ignore_index=True)
    return pix, counts, probe_day


def ensure_inventory(cfg: Config, b: boundaries.Boundary, client: Erddap, rebuild=False, log=print):
    folder = cfg.data_dir / b.site.slug
    meta_path = folder / "site.json"
    pix_path = folder / "pixels.csv"
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    if not rebuild and pix_path.exists() and meta.get("boundary", {}).get("digest") == b.digest:
        return pd.read_csv(pix_path), meta, False
    log(f"{b.site.code}: building pixel inventory")
    pix, counts, probe = build_inventory(cfg, b, client, log)
    io.write_csv(pix_path, pix, float_format="%.6f")
    meta.update(boundary=boundaries.boundary_meta(b), pixels=counts, inventory_probe_date=str(probe))
    io.write_json(meta_path, meta)
    return pix, meta, True


# ---------------------------------------------------------------------- daily
def month_chunks(d0: date, d1: date):
    a = d0
    while a <= d1:
        nxt = date(a.year + (a.month == 12), a.month % 12 + 1, 1)
        b = min(d1, nxt - timedelta(days=1))
        yield a, b
        a = b + timedelta(days=1)


def _read_daily(path):
    if not path.exists():
        return pd.DataFrame(columns=stats.DAILY_COLUMNS)
    return pd.read_csv(path, dtype={"date": str, "series": str})


def _merge(existing: pd.DataFrame, new: pd.DataFrame, d0: date, d1: date) -> pd.DataFrame:
    keep = existing[(existing["date"] < d0.isoformat()) | (existing["date"] > d1.isoformat())]
    out = pd.concat([keep, new], ignore_index=True) if len(keep) else new.copy()
    out = out.sort_values(["series", "date"], kind="stable").reset_index(drop=True)
    if out.duplicated(["series", "date"]).any():
        raise stats.DataQualityError("Duplicate series/date rows after merge")
    return out


def update_site(cfg: Config, site: Site, client: Erddap, *, start: date | None = None,
                end: date | None = None, refresh_boundary=False, rebuild_inventory=False,
                with_station=True, log=print) -> dict:
    folder = cfg.data_dir / site.slug
    b = boundaries.load(cfg, site, refresh=refresh_boundary)
    boundaries.export_geojson(b, folder / "boundary.geojson")
    pix, meta, rebuilt = ensure_inventory(cfg, b, client, rebuild_inventory, log)

    daily_path = folder / "daily.csv"
    existing = _read_daily(daily_path)
    if rebuilt and len(existing):
        log(f"{site.code}: boundary or inventory changed; discarding {len(existing)} existing daily rows")
        existing = existing.iloc[0:0]

    latest = client.latest_date()
    end = min(end or latest, latest)
    if start is not None:
        fetch_from = max(start, cfg.start_date)
    elif len(existing):
        last = date.fromisoformat(existing["date"].max())
        fetch_from = max(cfg.start_date, last - timedelta(days=cfg.lookback_days - 1))
    else:
        fetch_from = cfg.start_date

    unique = pix.drop_duplicates(["iy", "ix"]).reset_index(drop=True)
    key = {k: i for i, k in enumerate(zip(unique["iy"], unique["ix"]))}
    series_idx = {name: np.array([key[k] for k in zip(g["iy"], g["ix"])])
                  for name, g in pix.groupby("series", sort=False)}
    windows = grid.fetch_windows(unique["iy"].to_numpy(), unique["ix"].to_numpy())
    variables = list(cfg.variables)
    qc = []
    last_snapshot = None
    log(f"{site.code}: {len(unique)} water pixels in {len(windows)} window(s); "
        f"fetching {fetch_from} → {end}" if fetch_from <= end else f"{site.code}: up to date ({end})")

    for n, (a, z) in enumerate(month_chunks(fetch_from, end), start=1):
        dss = [client.fetch(a, z, w, variables) for w in windows]
        dates, vals = stats.sample(dss, unique, variables)
        frames = []
        for name, idx in series_idx.items():
            sub = {v: arr[:, idx] for v, arr in vals.items()}
            frames.append(stats.daily_stats(dates, sub, pix[pix["series"] == name], name))
        new = pd.concat(frames, ignore_index=True)
        allrows = new[new["series"] == boundaries.ALL]
        low = allrows[allrows["n_pixels"] < 0.5 * len(series_idx[boundaries.ALL])]
        if len(low):
            qc.append(f"{len(low)} day(s) in {a:%Y-%m} with <50% of pixels valid (first {low['date'].iloc[0]})")
        missing = (z - a).days + 1 - len(dates)
        if missing:
            qc.append(f"{missing} day(s) absent from ERDDAP in {a:%Y-%m}")
        existing = _merge(existing, new, a, z)
        last_snapshot = (dates[-1], {v: arr[-1] for v, arr in vals.items()})
        log(f"  {site.code} {a:%Y-%m}: {len(dates)} day(s)")
        if n % CHECKPOINT_EVERY == 0:
            io.write_csv(daily_path, existing)

    if fetch_from <= end:
        io.write_csv(daily_path, existing)
    if len(existing):
        # Light file for the viewer: last ~5 years of daily rows.
        cutoff = (date.fromisoformat(existing["date"].max()) - timedelta(days=RECENT_DAYS)).isoformat()
        io.write_csv(folder / "recent_daily.csv", existing[existing["date"] > cutoff])
    if last_snapshot is not None:
        day, arrs = last_snapshot
        snap = unique[["lat", "lon"]].copy()
        snap["date"] = str(pd.Timestamp(day).date())
        for v, col in [("CRW_SST", "sst"), ("CRW_SSTANOMALY", "ssta"), ("CRW_DHW", "dhw"), ("CRW_BAA", "baa")]:
            if v in arrs:
                snap[col] = arrs[v]
        io.write_csv(folder / "latest_pixels.csv", snap, float_format="%.3f")

    summarise_site(cfg, site, existing)
    station_meta = None
    if with_station and site.station:
        try:
            station_meta = stations.update(cfg, site, log)
        except Exception as err:  # station is a comparison layer; never block the main series
            qc.append(f"station update failed: {err}")
            log(f"  ! {site.code}: station update failed: {err}")

    meta = json.loads((folder / "site.json").read_text())
    meta.update(code=site.code, name=site.name, coral=site.coral,
                first_date=existing["date"].min() if len(existing) else None,
                last_date=existing["date"].max() if len(existing) else None,
                series=list(series_idx), boundary_url=site.boundary_url,
                updated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                qc=qc[-20:], erddap={"server": client.server, "dataset": client.dataset})
    if station_meta:
        meta["station"] = station_meta
    elif site.station is None:
        meta.pop("station", None)
    io.write_json(folder / "site.json", meta)
    return meta


def summarise_site(cfg: Config, site: Site, daily: pd.DataFrame | None = None) -> None:
    folder = cfg.data_dir / site.slug
    if daily is None:
        daily = _read_daily(folder / "daily.csv")
    if daily.empty:
        return
    mon = aggregate.monthly(daily)
    clim = aggregate.climatology(mon, cfg.climatology, cfg.min_baseline_years)
    mon = aggregate.apply_anomaly(mon, clim)
    io.write_csv(folder / "monthly.csv", mon)
    io.write_csv(folder / "climatology.csv", clim)


def write_manifest(cfg: Config) -> dict:
    sites = []
    for site in cfg.sites.values():
        p = cfg.data_dir / site.slug / "site.json"
        if p.exists():
            m = json.loads(p.read_text())
            m["has_station"] = (cfg.data_dir / site.slug / "station_monthly.csv").exists()
            sites.append(m)
    manifest = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "pipeline_version": __version__,
        "climatology": f"{cfg.climatology[0]}-{cfg.climatology[1]}",
        "baa_levels": stats.BAA_LEVELS,
        "sources": {
            "crw": "NOAA Coral Reef Watch, Daily Global 5km Satellite Coral Bleaching Heat Stress "
                   "Monitoring (CoralTemp v3.1), via ERDDAP dataset " + cfg.dataset,
            "boundaries": "NOAA Office of National Marine Sanctuaries GIS (iMAST) boundary files",
            "stations": "NOAA Coral Reef Watch 5km Regional Virtual Stations (experimental)",
        },
        "sites": sites,
    }
    io.write_json(cfg.data_dir / "manifest.json", manifest)
    return manifest
