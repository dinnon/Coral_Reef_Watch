"""CRW regional virtual station text files (comparison series).

Ported from the regional-station pilot: same strict parsing and identity check, plus
header metadata (MMM, monthly mean climatology) and monthly DHW/BAA maxima, which the
pilot dropped.
"""

from __future__ import annotations

import math
import re
from datetime import date, timedelta

import pandas as pd

from . import io
from .config import Config, Site

ROW = re.compile(r"^\s*(\d{4})\s+(\d{1,2})\s+(\d{1,2})\s+(.+?)\s*$")
DAILY_COLUMNS = ["date", "sst_min", "sst_max", "sst_at_hs90", "ssta_at_hs90",
                 "hotspot_hs90", "dhw_from_hs90", "baa_7day_max"]
MONTHLY_COLUMNS = ["month", "days_reported", "days_in_month", "complete_month",
                   "sst_at_hs90_mean", "sst_min_mean", "sst_max_mean", "ssta_at_hs90_mean",
                   "dhw_max", "baa_max", "days_alert1_plus"]


def _header_value(source: str, label: str) -> str | None:
    m = re.search(rf"(?m)^{re.escape(label)}:\s*\r?\n([^\r\n]+)", source)
    return m.group(1).strip() if m else None


def parse(source: str, expected_name: str) -> tuple[pd.DataFrame, dict]:
    name = _header_value(source, "Name")
    if name != expected_name:
        raise ValueError(f"Station identity mismatch: expected {expected_name!r}, got {name!r}")
    if "SST@90th_HS" not in source or "SST_MIN" not in source:
        raise ValueError("Unrecognised NOAA time-series header")
    meta = {"name": name}
    for key, label in [("lon", "Polygon Middle Longitude"), ("lat", "Polygon Middle Latitude"),
                       ("mmm", "Averaged Maximum Monthly Mean")]:
        v = _header_value(source, label)
        meta[key] = float(v) if v else None
    mm = _header_value(source, "Averaged Monthly Mean (Jan-Dec)")
    meta["monthly_means"] = [float(x) for x in mm.split()] if mm else None

    rows = []
    matches = [m for m in map(ROW.match, source.splitlines()) if m]
    # A file caught mid-update can end in a truncated line; drop only that one.
    if matches and len(matches[-1].group(4).split()) != 7:
        meta["dropped_partial_last_line"] = True
        matches = matches[:-1]
    for m in matches:
        day = date(*(int(m.group(i)) for i in (1, 2, 3)))
        values = m.group(4).split()
        if len(values) != 7:
            raise ValueError(f"Unexpected field count on {day}: {len(values)}")
        nums = [float(v) for v in values[:6]]
        if not all(math.isfinite(v) for v in nums):
            raise ValueError(f"Non-finite value on {day}")
        if not (-2.5 <= nums[0] <= 40 and -2.5 <= nums[1] <= 40 and -2.5 <= nums[2] <= 40):
            raise ValueError(f"SST out of range on {day}")
        if nums[5] < 0:
            raise ValueError(f"Negative DHW on {day}")
        baa = int(values[6])
        if not 0 <= baa <= 7:
            raise ValueError(f"Alert level {baa} out of range on {day}")
        rows.append((day.isoformat(), *nums, baa))
    if not rows:
        raise ValueError("No daily observations")
    df = pd.DataFrame(rows, columns=DAILY_COLUMNS)
    if not df["date"].is_monotonic_increasing or df["date"].duplicated().any():
        raise ValueError("Daily dates are unordered or repeated")
    return df, meta


def missing_dates(daily: pd.DataFrame) -> list[date]:
    days = [date.fromisoformat(d) for d in daily["date"]]
    return [a + timedelta(days=k) for a, b in zip(days, days[1:]) for k in range(1, (b - a).days)]


def monthly(daily: pd.DataFrame) -> pd.DataFrame:
    d = daily.assign(month=daily["date"].str[:7], _a1=(daily["baa_7day_max"] >= 3).astype(int))
    out = d.groupby("month").agg(
        days_reported=("date", "count"),
        sst_at_hs90_mean=("sst_at_hs90", "mean"), sst_min_mean=("sst_min", "mean"),
        sst_max_mean=("sst_max", "mean"), ssta_at_hs90_mean=("ssta_at_hs90", "mean"),
        dhw_max=("dhw_from_hs90", "max"), baa_max=("baa_7day_max", "max"),
        days_alert1_plus=("_a1", "sum"),
    ).reset_index()
    out["days_in_month"] = pd.PeriodIndex(out["month"], freq="M").days_in_month
    out["complete_month"] = (out["days_reported"] == out["days_in_month"]).astype(int)
    return out[MONTHLY_COLUMNS]


def update(cfg: Config, site: Site, log=print) -> dict | None:
    if not site.station:
        return None
    url = cfg.station_base_url + site.station.file
    body = io.get(url, timeout=120).decode("utf-8-sig")
    daily, meta = parse(body, site.station.name)
    folder = cfg.data_dir / site.slug
    io.write_csv(folder / "station_daily.csv", daily)
    io.write_csv(folder / "station_monthly.csv", monthly(daily))
    gaps = missing_dates(daily)
    log(f"{site.code}: station '{site.station.name}' {len(daily)} days through {daily['date'].iloc[-1]}"
        + (f"; {len(gaps)} missing date(s), first {gaps[0]}" if gaps else ""))
    meta.update(url=url, last_date=daily["date"].iloc[-1], missing_days=len(gaps))
    return meta
