"""Coral Reef Watch summaries clipped to NOAA Office of National Marine Sanctuaries boundaries."""

__version__ = "0.1.0"
