"""Per-day zonal statistics over a sanctuary's pixel inventory."""

from __future__ import annotations

import numpy as np
import pandas as pd
import xarray as xr

from . import grid

# CRW 5 km v3.1 Bleaching Alert Area codes (levels 5-7 added 15 Dec 2023).
BAA_LEVELS = {0: "No Stress", 1: "Watch", 2: "Warning", 3: "Alert 1",
              4: "Alert 2", 5: "Alert 3", 6: "Alert 4", 7: "Alert 5"}

DAILY_COLUMNS = (
    ["date", "series", "n_pixels", "valid_area_frac",
     "sst_mean", "sst_p10", "sst_p50", "sst_p90", "sst_min", "sst_max",
     "ssta_mean", "ssta_p90", "hotspot_max",
     "dhw_mean", "dhw_p90", "dhw_max", "dhw_frac_ge4", "dhw_frac_ge8",
     "baa_max"] + [f"baa_frac_{k}" for k in BAA_LEVELS]
)

RANGES = {"CRW_SST": (-2.5, 40.0), "CRW_SSTANOMALY": (-15, 15), "CRW_HOTSPOT": (-15, 15),
          "CRW_DHW": (0, 100), "CRW_BAA": (0, 7)}


class DataQualityError(ValueError):
    pass


def sample(datasets: list[xr.Dataset], pixels: pd.DataFrame, variables) -> tuple[np.ndarray, dict]:
    """Values at inventory pixels: (dates, {var: array[time, pixel]})."""
    n = len(pixels)
    out: dict[str, np.ndarray] = {}
    dates = None
    iy, ix = pixels["iy"].to_numpy(), pixels["ix"].to_numpy()
    found = np.zeros(n, dtype=bool)
    for ds in datasets:
        d = ds["time"].values
        if dates is None:
            dates = d
            for v in variables:
                out[v] = np.full((len(d), n), np.nan, dtype="float32")
        elif not np.array_equal(d, dates):
            raise DataQualityError("ERDDAP windows returned different time axes")
        giy = grid.lat_index(ds["latitude"].values)
        gix = grid.lon_index(ds["longitude"].values)
        if np.any(np.diff(giy) != 1) or np.any(np.diff(gix) != 1):
            raise DataQualityError("ERDDAP returned a non-contiguous or off-grid window")
        sel = (iy >= giy[0]) & (iy <= giy[-1]) & (ix >= gix[0]) & (ix <= gix[-1])
        r, c = iy[sel] - giy[0], ix[sel] - gix[0]
        for v in variables:
            out[v][:, sel] = ds[v].values[:, r, c]
        found |= sel
    if dates is None:
        raise DataQualityError("No data returned")
    if not found.all():
        raise DataQualityError(f"{(~found).sum()} inventory pixels fell outside the fetched windows")
    for v, (lo, hi) in RANGES.items():
        if v in out:
            vals = out[v]
            bad = np.isfinite(vals) & ((vals < lo) | (vals > hi))
            if bad.any():
                raise DataQualityError(f"{v}: {bad.sum()} values outside [{lo}, {hi}]")
    return dates, out


def weighted_quantiles(values: np.ndarray, weights: np.ndarray, qs) -> np.ndarray:
    """Row-wise weighted quantiles ignoring NaN. values/weights: (T, N)."""
    T = values.shape[0]
    res = np.full((T, len(qs)), np.nan)
    order = np.argsort(np.where(np.isfinite(values), values, np.inf), axis=1)
    v = np.take_along_axis(values, order, axis=1)
    w = np.take_along_axis(np.where(np.isfinite(values), weights, 0.0), order, axis=1)
    cw = np.cumsum(w, axis=1)
    tot = cw[:, -1]
    for t in np.nonzero(tot > 0)[0]:
        k = w[t] > 0
        vv, ww = v[t, k], w[t, k]
        # Midpoint (Hazen-like) plotting positions: unbiased for equal weights.
        pos = (np.cumsum(ww) - 0.5 * ww) / ww.sum()
        res[t] = np.interp(qs, pos, vv)
    return res


def _wmean(values, w):
    ok = np.isfinite(values)
    ww = np.where(ok, w, 0.0)
    s = ww.sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(s > 0, np.nansum(np.where(ok, values, 0.0) * ww, axis=1) / s, np.nan), s


def _nanmax(a):
    with np.errstate(all="ignore"):
        ok = np.isfinite(a).any(axis=1)
        return np.where(ok, np.nanmax(np.where(np.isfinite(a), a, -np.inf), axis=1), np.nan)


def _nanmin(a):
    with np.errstate(all="ignore"):
        ok = np.isfinite(a).any(axis=1)
        return np.where(ok, np.nanmin(np.where(np.isfinite(a), a, np.inf), axis=1), np.nan)


def _frac(mask, valid, w):
    num = (np.where(mask & valid, w, 0.0)).sum(axis=1)
    den = (np.where(valid, w, 0.0)).sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(den > 0, num / den, np.nan)


def daily_stats(dates, values: dict, pixels: pd.DataFrame, series: str) -> pd.DataFrame:
    w = pixels["weight"].to_numpy()[None, :]
    total_w = float(w.sum())
    sst = values["CRW_SST"]
    sst_mean, sst_w = _wmean(sst, w)
    q = weighted_quantiles(sst, np.broadcast_to(w, sst.shape), [0.1, 0.5, 0.9])
    df = pd.DataFrame({
        "date": pd.to_datetime(dates).strftime("%Y-%m-%d"),
        "series": series,
        "n_pixels": np.isfinite(sst).sum(axis=1),
        "valid_area_frac": sst_w / total_w if total_w else np.nan,
        "sst_mean": sst_mean, "sst_p10": q[:, 0], "sst_p50": q[:, 1], "sst_p90": q[:, 2],
        "sst_min": _nanmin(sst), "sst_max": _nanmax(sst),
    })
    if "CRW_SSTANOMALY" in values:
        a = values["CRW_SSTANOMALY"]
        df["ssta_mean"] = _wmean(a, w)[0]
        df["ssta_p90"] = weighted_quantiles(a, np.broadcast_to(w, a.shape), [0.9])[:, 0]
    if "CRW_HOTSPOT" in values:
        df["hotspot_max"] = _nanmax(values["CRW_HOTSPOT"])
    if "CRW_DHW" in values:
        d = values["CRW_DHW"]
        ok = np.isfinite(d)
        df["dhw_mean"] = _wmean(d, w)[0]
        df["dhw_p90"] = weighted_quantiles(d, np.broadcast_to(w, d.shape), [0.9])[:, 0]
        df["dhw_max"] = _nanmax(d)
        df["dhw_frac_ge4"] = _frac(d >= 4, ok, w)
        df["dhw_frac_ge8"] = _frac(d >= 8, ok, w)
    if "CRW_BAA" in values:
        b = values["CRW_BAA"]
        ok = np.isfinite(b)
        df["baa_max"] = _nanmax(b)
        bi = np.where(ok, np.rint(b), -1).astype(int)
        for k in BAA_LEVELS:
            df[f"baa_frac_{k}"] = _frac(bi == k, ok, w)
    for c in DAILY_COLUMNS:
        if c not in df:
            df[c] = np.nan
    return df[list(DAILY_COLUMNS)]
