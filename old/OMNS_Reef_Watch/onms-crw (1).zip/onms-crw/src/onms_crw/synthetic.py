"""Synthetic CRW-like fields and boundaries for tests and the offline demo.

Nothing here is real data. The demo site names say so, and the viewer shows a banner
whenever the manifest carries `"synthetic": true`.
"""

from __future__ import annotations

import zipfile
from datetime import date, timedelta
from pathlib import Path

import geopandas as gpd
import numpy as np
import xarray as xr
from shapely.geometry import Point, Polygon, box

from . import grid
from .erddap import Erddap


class FakeErddap(Erddap):
    """Serves deterministic synthetic fields in ERDDAP's layout (descending latitude)."""

    def __init__(self, variables, latest: date, islands=(), seed=0, gaps=()):
        super().__init__(["synthetic://"], "NOAA_DHW", variables, pause_s=0)
        self.server = "synthetic://"
        self._latest = latest
        self.islands = list(islands)          # (lat, lon, radius_deg) -> land (NaN)
        self.seed = seed
        self.gaps = set(gaps)                 # dates ERDDAP "doesn't have"
        self.requests = []

    def latest_date(self) -> date:
        return self._latest

    def fetch(self, d0, d1, win, variables=None):
        variables = list(variables or self.variables)
        self.requests.append((d0, d1, win, tuple(variables)))
        y0, y1, x0, x1 = win
        lats = grid.lat_center(np.arange(y1, y0 - 1, -1))      # descending, like ERDDAP
        lons = grid.lon_center(np.arange(x0, x1 + 1))
        days = [d0 + timedelta(days=k) for k in range((d1 - d0).days + 1)]
        days = [d for d in days if d not in self.gaps and d <= self._latest]
        LAT, LON = np.meshgrid(lats, lons, indexing="ij")
        land = np.zeros(LAT.shape, bool)
        for la, lo, r in self.islands:
            dlon = ((LON - lo + 180) % 360) - 180
            land |= (LAT - la) ** 2 + dlon ** 2 <= r ** 2
        data = {v: np.empty((len(days),) + LAT.shape, "float32") for v in variables}
        for i, d in enumerate(days):
            f = field(d, LAT, LON)
            for v in variables:
                arr = f[v].astype("float32")
                arr[land] = np.nan
                data[v][i] = arr
        ds = xr.Dataset({v: (("time", "latitude", "longitude"), a) for v, a in data.items()},
                        coords={"time": np.array(days, dtype="datetime64[ns]") + np.timedelta64(12, "h"),
                                "latitude": lats, "longitude": lons})
        from .erddap import normalise
        return normalise(ds)


def field(d: date, LAT, LON) -> dict:
    """Plausible tropical SST seasonal cycle with a marine heatwave in late summer 2023-ish years."""
    doy = d.timetuple().tm_yday
    year = d.year
    hemi = np.where(LAT >= 0, 1.0, -1.0)
    base = 27.0 - 0.18 * (np.abs(LAT) - 20)                           # warmer equatorward
    seas = 2.2 * hemi * np.sin(2 * np.pi * (doy - 120) / 365.25)
    trend = 0.02 * (year + doy / 365.25 - 2000)
    wiggle = 0.25 * np.sin(LON * 1.7 + d.toordinal() / 9.0) * np.cos(LAT * 2.3)
    # Heat-wave years: peaks around late Aug (north) / early Mar (south).
    centre = np.where(hemi > 0, 235, 60)
    amp = {1998: 1.2, 2005: 1.0, 2010: 0.9, 2014: 1.0, 2015: 1.3, 2019: 1.0, 2023: 2.0, 2024: 1.4}.get(year, 0.0)
    hw = amp * np.exp(-0.5 * ((doy - centre) / 25.0) ** 2) * np.ones_like(LAT)
    clim = base + seas
    sst = clim + trend + wiggle + hw
    hotspot = np.maximum(sst - (base + 2.2), 0)
    dhw = np.maximum(amp * 9 * np.exp(-0.5 * ((doy - centre - 25) / 40.0) ** 2) * (1 + 0.3 * np.cos(LON * 3)), 0)
    baa = np.select([hotspot <= 0, hotspot < 1, dhw < 4, dhw < 8, dhw < 12, dhw < 16, dhw < 20],
                    [0, 1, 2, 3, 4, 5, 6], 7).astype(float)
    return {"CRW_SST": sst, "CRW_SSTANOMALY": sst - clim + 0.1, "CRW_HOTSPOT": hotspot,
            "CRW_DHW": dhw, "CRW_BAA": baa, "CRW_SEAICE": np.zeros_like(sst)}


def write_boundary_zip(path: Path, gdf: gpd.GeoDataFrame, stem: str) -> Path:
    tmp = path.parent / f".{stem}_shp"
    tmp.mkdir(parents=True, exist_ok=True)
    gdf.to_file(tmp / f"{stem}.shp")
    with zipfile.ZipFile(path, "w") as z:
        for f in tmp.iterdir():
            z.write(f, f.name)
            f.unlink()
    tmp.rmdir()
    return path


def demo_boundaries() -> dict[str, gpd.GeoDataFrame]:
    """Plain shapes, deliberately not resembling any real sanctuary."""
    a_main = Polygon([(-80.9, 24.3), (-79.6, 24.3), (-79.4, 25.0), (-80.2, 25.3), (-80.9, 24.9)])
    a_tiny = Point(-79.0, 24.6).buffer(0.01)          # ~1 km: smaller than one CRW pixel
    demo_a = gpd.GeoDataFrame({"UNIT": ["Main area", "Tiny bank"]}, geometry=[a_main, a_tiny], crs=4326)
    # Straddles the antimeridian, stored as two parts split at ±180 as many shapefiles do.
    east = box(178.5, 25.0, 180.0, 27.0)
    west = box(-180.0, 25.0, -176.0, 27.0)
    demo_b = gpd.GeoDataFrame({"NAME": ["Demo Atolls", "Demo Atolls"]}, geometry=[east, west], crs=4326)
    return {"DEMOA": demo_a, "DEMOB": demo_b}


DEMO_ISLANDS = [(24.7, -80.0, 0.12), (24.6, -79.0, 0.03), (26.0, 179.9, 0.15)]

DEMO_CONFIG = """
[pipeline]
start_date = "{start}"
lookback_days = 10
climatology = [1991, 2020]
min_baseline_years = 25
fallback_km = 15
request_pause_s = 0

[erddap]
servers = ["synthetic://"]
dataset = "NOAA_DHW"
variables = ["CRW_SST", "CRW_SSTANOMALY", "CRW_HOTSPOT", "CRW_DHW", "CRW_BAA"]

[stations]
base_url = "synthetic://"

[sites.DEMOA]
name = "Demo Sanctuary A (SYNTHETIC DATA)"
boundary_url = "synthetic://demoa.zip"
coral = true
enabled = true
unit_field = "UNIT"

[sites.DEMOB]
name = "Demo Atolls B, crosses 180° (SYNTHETIC DATA)"
boundary_url = "synthetic://demob.zip"
coral = true
enabled = true
"""


def build_demo(out: Path, start: str = "1985-04-01", latest: date = date(2026, 9, 30), log=print):
    """Create a self-contained synthetic project at `out` and run the real pipeline on it."""
    from . import config as config_mod, pipeline
    out = Path(out)
    (out / "config").mkdir(parents=True, exist_ok=True)
    (out / "config" / "sanctuaries.toml").write_text(DEMO_CONFIG.format(start=start))
    cfg = config_mod.load(out / "config" / "sanctuaries.toml", root=out)
    for code, gdf in demo_boundaries().items():
        path = cfg.cache_dir / "boundaries" / f"{code.lower()}.zip"
        path.parent.mkdir(parents=True, exist_ok=True)
        write_boundary_zip(path, gdf, f"{code.lower()}_py")
    client = FakeErddap(cfg.variables, latest=latest, islands=DEMO_ISLANDS,
                        gaps={date(2003, 2, 10), date(2003, 2, 11)})
    for site in cfg.select(None):
        pipeline.update_site(cfg, site, client, log=log)
    _demo_station(cfg, client, date.fromisoformat(start), latest)
    manifest = pipeline.write_manifest(cfg)
    manifest["synthetic"] = True
    from . import io
    io.write_json(cfg.data_dir / "manifest.json", manifest)
    return cfg


def station_text(name: str, lat: float, lon: float, d0: date, d1: date) -> str:
    """A NOAA-format regional virtual station file built from the synthetic field."""
    lines = ["Name:", name, " ", "Polygon Middle Longitude:", f"{lon:.4f} ", " ",
             "Polygon Middle Latitude:", f"{lat:.4f} ", " ",
             "YYYY MM DD SST_MIN SST_MAX SST@90th_HS SSTA@90th_HS 90th_HS>0 DHW_from_90th_HS>1 BAA_7day_max"]
    LAT, LON = np.array([[lat]]), np.array([[lon]])
    d = d0
    while d <= d1:
        f = {k: float(v[0, 0]) for k, v in field(d, LAT, LON).items()}
        lines.append(f"{d.year} {d.month:02d} {d.day:02d} {f['CRW_SST'] - 0.6:7.4f} {f['CRW_SST'] + 0.5:7.4f} "
                     f"{f['CRW_SST'] + 0.3:7.4f} {f['CRW_SSTANOMALY'] + 0.2:11.4f} {f['CRW_HOTSPOT']:12.4f} "
                     f"{f['CRW_DHW'] * 1.1:9.4f} {int(f['CRW_BAA']):12d}")
        d += timedelta(days=1)
    return "\n".join(lines) + "\n"


def _demo_station(cfg, client, d0, d1):
    """Give DEMOA a synthetic comparison station so the overlay can be exercised offline."""
    import json
    from . import io, stations
    site = cfg.sites["DEMOA"]
    name = "Demo Reef Station (SYNTHETIC)"
    text = station_text(name, 24.6, -80.2, d0, d1)
    daily, meta = stations.parse(text, name)
    folder = cfg.data_dir / site.slug
    io.write_csv(folder / "station_daily.csv", daily)
    io.write_csv(folder / "station_monthly.csv", stations.monthly(daily))
    sj = json.loads((folder / "site.json").read_text())
    sj["station"] = {**meta, "url": "synthetic", "last_date": daily["date"].iloc[-1], "missing_days": 0}
    io.write_json(folder / "site.json", sj)
