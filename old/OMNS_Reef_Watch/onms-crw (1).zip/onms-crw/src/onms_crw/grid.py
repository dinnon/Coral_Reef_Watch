"""CRW 0.05° grid geometry and per-sanctuary pixel inventories."""

from __future__ import annotations

import numpy as np
import pandas as pd
import shapely

RES = 0.05
LAT0 = -89.975   # first pixel centre (south)
LON0 = -179.975  # first pixel centre (west)
NLAT, NLON = 3600, 7200


def lat_index(lat) -> np.ndarray:
    return np.rint((np.asarray(lat, dtype=float) - LAT0) / RES).astype(int)


def lon_index(lon) -> np.ndarray:
    """Global column index for any longitude (wraps 0-360 frames back)."""
    native = ((np.asarray(lon, dtype=float) + 180.0) % 360.0) - 180.0
    return np.rint((native - LON0) / RES).astype(int) % NLON


def lat_center(iy) -> np.ndarray:
    return LAT0 + np.asarray(iy) * RES


def lon_center(ix) -> np.ndarray:
    return LON0 + np.asarray(ix) * RES


def candidate_pixels(geom, frame: int, pad: float = 0.0):
    """Pixel centres (frame coords) whose 0.05° cell could touch geom (+pad degrees)."""
    minx, miny, maxx, maxy = geom.bounds
    minx, miny, maxx, maxy = minx - pad, miny - pad, maxx + pad, maxy + pad
    iy = np.arange(max(0, int(np.floor((miny - LAT0) / RES))), min(NLAT, int(np.ceil((maxy - LAT0) / RES)) + 1))
    # Work in frame longitudes, stepping on the grid phase.
    k0 = int(np.floor((minx - LON0) / RES))
    k1 = int(np.ceil((maxx - LON0) / RES))
    lons = LON0 + np.arange(k0, k1 + 1) * RES
    if frame == 360:
        lons = lons[(lons >= 0) & (lons < 360)]
    else:
        lons = lons[(lons >= -180) & (lons <= 180)]
    lats = lat_center(iy)
    return lats, lons


def inventory(geom, frame: int) -> pd.DataFrame:
    """All pixels touching geom, with fractional cover and area weight.

    weight = cover_fraction * cos(lat): proportional to the area of the pixel that lies
    inside the boundary, so small or ragged sanctuaries are not dominated by edge pixels.
    """
    lats, lons = candidate_pixels(geom, frame)
    if not len(lats) or not len(lons):
        return _empty()
    LON, LAT = np.meshgrid(lons, lats)
    LON, LAT = LON.ravel(), LAT.ravel()
    h = RES / 2
    boxes = shapely.box(LON - h, LAT - h, LON + h, LAT + h)
    prepared = geom
    shapely.prepare(prepared)
    touch = shapely.intersects(prepared, boxes)
    if not touch.any():
        return _empty()
    boxes, LON, LAT = boxes[touch], LON[touch], LAT[touch]
    frac = shapely.area(shapely.intersection(boxes, geom)) / (RES * RES)
    keep = frac > 1e-6
    LON, LAT, frac = LON[keep], LAT[keep], np.clip(frac[keep], 0, 1)
    inside = shapely.contains_xy(geom, LON, LAT)
    return pd.DataFrame({
        "lat": np.round(LAT, 3), "lon": np.round(LON, 3),
        "iy": lat_index(LAT), "ix": lon_index(LON),
        "cover": np.round(frac, 5), "center_inside": inside,
        "weight": frac * np.cos(np.deg2rad(LAT)), "fallback": False,
    })


def _empty() -> pd.DataFrame:
    return pd.DataFrame({c: pd.Series(dtype=t) for c, t in [
        ("lat", float), ("lon", float), ("iy", int), ("ix", int), ("cover", float),
        ("center_inside", bool), ("weight", float), ("fallback", bool)]})


def haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = np.deg2rad(lat1), np.deg2rad(lat2)
    dl = np.deg2rad(np.asarray(lon2) - np.asarray(lon1))
    a = np.sin((p2 - p1) / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 6371.0088 * 2 * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def fetch_windows(iy: np.ndarray, ix: np.ndarray) -> list[tuple[int, int, int, int]]:
    """Rectangles (iy0, iy1, ix0, ix1), inclusive, covering the pixels.

    One rectangle normally; two when the pixels straddle the antimeridian (ix wraps)."""
    if len(iy) == 0:
        return []
    y0, y1 = int(iy.min()), int(iy.max())
    cols = np.unique(ix)
    if len(cols) == 1:
        return [(y0, y1, int(cols[0]), int(cols[0]))]
    gaps = np.diff(cols)
    k = int(np.argmax(gaps))
    wrap_gap = cols[0] + NLON - cols[-1]
    if gaps[k] > wrap_gap:
        # Pixels straddle the antimeridian: east part then west part.
        return [(y0, y1, int(cols[k + 1]), int(cols[-1])), (y0, y1, int(cols[0]), int(cols[k]))]
    return [(y0, y1, int(cols[0]), int(cols[-1]))]
