"""Monthly summaries and the sanctuary SST climatology/anomaly."""

from __future__ import annotations

import numpy as np
import pandas as pd

MONTHLY_COLUMNS = [
    "month", "series", "days_reported", "days_in_month", "complete_month",
    "sst_mean", "sst_p10", "sst_p90", "sst_min", "sst_max",
    "sst_clim", "sst_anom", "ssta_crw_mean",
    "dhw_max", "dhw_mean_max", "peak_frac_dhw_ge4", "peak_frac_dhw_ge8",
    "baa_max", "days_alert1_plus", "peak_frac_alert1_plus", "peak_frac_alert2_plus",
]


def monthly(daily: pd.DataFrame) -> pd.DataFrame:
    if daily.empty:
        return pd.DataFrame(columns=MONTHLY_COLUMNS)
    d = daily.copy()
    d["month"] = d["date"].str[:7]
    alert1 = d[[f"baa_frac_{k}" for k in range(3, 8)]].sum(axis=1, min_count=1)
    alert2 = d[[f"baa_frac_{k}" for k in range(4, 8)]].sum(axis=1, min_count=1)
    d["_a1"], d["_a2"] = alert1, alert2
    d["_a1day"] = (d["baa_max"] >= 3).astype(float).where(d["baa_max"].notna())
    # A day only counts toward completeness if it has any valid SST.
    d["_ok"] = d["n_pixels"] > 0
    g = d.groupby(["series", "month"], sort=True)
    out = g.agg(
        days_reported=("_ok", "sum"),
        sst_mean=("sst_mean", "mean"), sst_p10=("sst_p10", "mean"), sst_p90=("sst_p90", "mean"),
        sst_min=("sst_min", "min"), sst_max=("sst_max", "max"),
        ssta_crw_mean=("ssta_mean", "mean"),
        dhw_max=("dhw_max", "max"), dhw_mean_max=("dhw_mean", "max"),
        peak_frac_dhw_ge4=("dhw_frac_ge4", "max"), peak_frac_dhw_ge8=("dhw_frac_ge8", "max"),
        baa_max=("baa_max", "max"), days_alert1_plus=("_a1day", "sum"),
        peak_frac_alert1_plus=("_a1", "max"), peak_frac_alert2_plus=("_a2", "max"),
    ).reset_index()
    per = pd.PeriodIndex(out["month"], freq="M")
    out["days_in_month"] = per.days_in_month
    out["days_reported"] = out["days_reported"].astype(int)
    out["days_alert1_plus"] = out["days_alert1_plus"].astype(int)
    out["complete_month"] = (out["days_reported"] == out["days_in_month"]).astype(int)
    out["sst_clim"] = np.nan
    out["sst_anom"] = np.nan
    return out[MONTHLY_COLUMNS]


def climatology(mon: pd.DataFrame, years: tuple[int, int], min_years: int) -> pd.DataFrame:
    """Calendar-month mean of complete-month sst_mean over the baseline years."""
    y0, y1 = years
    m = mon[(mon["complete_month"] == 1)].copy()
    m["year"] = m["month"].str[:4].astype(int)
    m["moy"] = m["month"].str[5:7].astype(int)
    m = m[(m["year"] >= y0) & (m["year"] <= y1)]
    clim = m.groupby(["series", "moy"]).agg(sst_clim=("sst_mean", "mean"), n_years=("sst_mean", "count"),
                                            sst_sd=("sst_mean", "std")).reset_index()
    clim["published"] = (clim["n_years"] >= min_years).astype(int)
    clim["baseline"] = f"{y0}-{y1}"
    return clim[["series", "moy", "baseline", "n_years", "published", "sst_clim", "sst_sd"]]


def apply_anomaly(mon: pd.DataFrame, clim: pd.DataFrame) -> pd.DataFrame:
    c = clim[clim["published"] == 1][["series", "moy", "sst_clim"]]
    m = mon.drop(columns=["sst_clim", "sst_anom"])
    m["moy"] = m["month"].str[5:7].astype(int)
    m = m.merge(c, on=["series", "moy"], how="left")
    m["sst_anom"] = np.where(m["complete_month"] == 1, m["sst_mean"] - m["sst_clim"], np.nan)
    return m[MONTHLY_COLUMNS]
