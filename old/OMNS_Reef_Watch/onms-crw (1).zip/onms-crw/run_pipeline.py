"""
Run the ONMS Coral Reef Watch pipeline from your IDE.

1. Edit the SETTINGS block below.
2. Press Run (F5 in VS Code / Spyder, Shift+F10 in PyCharm).

No package install or terminal commands are needed beyond the Python libraries
in environment.yml. Everything is read from and written to this folder.
"""

# ============================== SETTINGS ===================================

# What to do:
#   "demo"     build SYNTHETIC test data offline, then open the viewer
#   "inspect"  download boundary zips and print their layers / attributes
#   "update"   pull real NOAA CRW data for SITES (incremental after the first run)
#   "stations" refresh only the CRW regional-station comparison files
#   "view"     just open the viewer on what is already in data/
#   "test"     run the automated test suite
MODE = "demo"

# ONMS codes from config/sanctuaries.toml. Empty list = every enabled sanctuary.
#   FKNMS  FGBNMS  NMSAS  PNMS  HIHWNMS  GRNMS   (PNMS is very large; do it last)
SITES = ["FKNMS"]

# Date range for "update". START=None means: continue from where data/ left off
# (or from 1985 on a first run). Use a recent START for a quick first test.
START = "2024-01-01"
END = None

# Open the viewer in your browser when the run finishes (stop with the IDE's Stop button).
OPEN_VIEWER = True
PORT = 8000

# "demo" only: first year of synthetic data (later = faster).
DEMO_START = "2015-01-01"

# ============================================================================

import functools
import http.server
import os
import socketserver
import sys
import threading
import time
import traceback
import webbrowser
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))      # use the code in this folder, no install needed
os.chdir(ROOT)

CONFIG = ROOT / "config" / "sanctuaries.toml"
DEMO_DIR = ROOT / "demo"


def check_libraries():
    missing = []
    for mod in ["numpy", "pandas", "xarray", "netCDF4", "geopandas", "shapely", "pyogrio", "pyproj", "requests"]:
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if missing:
        print("Missing Python libraries: " + ", ".join(missing))
        print("Easiest fix (Anaconda Prompt, in this folder):")
        print("    conda env create -f environment.yml")
        print("    conda activate onms-crw")
        print("then select the 'onms-crw' interpreter in your IDE and run again.")
        sys.exit(1)


def as_date(s):
    return date.fromisoformat(s) if s else None


def run_update():
    from onms_crw import config, pipeline
    from onms_crw.erddap import Erddap

    cfg = config.load(CONFIG, root=ROOT)
    sites = cfg.select(SITES)
    client = Erddap(cfg.servers, cfg.dataset, cfg.variables, cfg.request_pause_s, cfg.cache_dir)
    print(f"Sites: {', '.join(s.code for s in sites)}   range: {START or 'incremental'} → {END or 'latest'}\n")
    failed = []
    for site in sites:
        t0 = time.time()
        try:
            pipeline.update_site(cfg, site, client, start=as_date(START), end=as_date(END))
            print(f"✓ {site.code} done in {time.time() - t0:.0f} s\n")
        except Exception:
            failed.append(site.code)
            print(f"✗ {site.code} failed:")
            traceback.print_exc()
            print()
    pipeline.write_manifest(cfg)
    if failed:
        print("Failed: " + ", ".join(failed) + "  (paste the error above into the chat)")
    return ROOT / "data"


def run_inspect():
    from onms_crw import boundaries, config
    cfg = config.load(CONFIG, root=ROOT)
    for site in cfg.select(SITES, include_disabled=not SITES):
        print(boundaries.describe(boundaries.download(cfg, site), site), "\n")


def run_stations():
    from onms_crw import config, pipeline, stations
    cfg = config.load(CONFIG, root=ROOT)
    for site in cfg.select(SITES):
        stations.update(cfg, site)
    pipeline.write_manifest(cfg)
    return ROOT / "data"


def run_demo():
    from onms_crw import synthetic
    print(f"Building synthetic demo from {DEMO_START} (takes ~10-60 s)…")
    synthetic.build_demo(DEMO_DIR, start=DEMO_START, log=lambda *_: None)
    print(f"Done: {DEMO_DIR / 'data'}  (SYNTHETIC — not NOAA observations)")
    return DEMO_DIR / "data"


def run_tests():
    import pytest
    code = pytest.main(["-q", str(ROOT / "tests")])
    print("All tests passed." if code == 0 else "Some tests failed (see above).")


def serve(data_dir: Path):
    """Serve site/ at /site/ and the chosen data folder at /data/, then open the browser."""
    site_dir = ROOT / "site"

    class Handler(http.server.SimpleHTTPRequestHandler):
        def translate_path(self, path):
            path = path.split("?", 1)[0].split("#", 1)[0]
            if path.startswith("/data/"):
                return str(data_dir / path[len("/data/"):])
            if path.startswith("/site/"):
                return str(site_dir / path[len("/site/"):])
            return str(site_dir / "__none__")

        def end_headers(self):
            self.send_header("Cache-Control", "no-store")
            super().end_headers()

        def log_message(self, *args):
            pass

        def do_GET(self):
            if self.path in ("/", ""):
                self.send_response(302)
                self.send_header("Location", "/site/")
                self.end_headers()
                return
            super().do_GET()

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.ThreadingTCPServer(("127.0.0.1", PORT), Handler) as httpd:
        url = f"http://localhost:{PORT}/site/"
        print(f"\nViewer: {url}   (showing {data_dir})")
        print("Stop the run in your IDE to close it.")
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass


def main():
    check_libraries()
    data_dir = None
    if MODE == "demo":
        data_dir = run_demo()
    elif MODE == "update":
        data_dir = run_update()
    elif MODE == "inspect":
        run_inspect()
    elif MODE == "stations":
        data_dir = run_stations()
    elif MODE == "view":
        data_dir = DEMO_DIR / "data" if not (ROOT / "data" / "manifest.json").exists() else ROOT / "data"
    elif MODE == "test":
        run_tests()
    else:
        sys.exit(f"Unknown MODE {MODE!r}")

    if OPEN_VIEWER and data_dir is not None:
        if not (data_dir / "manifest.json").exists():
            print(f"No manifest in {data_dir}; nothing to show yet.")
        else:
            serve(data_dir)


if __name__ == "__main__":
    main()
