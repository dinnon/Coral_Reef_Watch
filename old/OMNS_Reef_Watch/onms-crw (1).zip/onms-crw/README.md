# onms-crw — Coral Reef Watch at National Marine Sanctuary boundaries

An automated pipeline and static viewer that summarise NOAA Coral Reef Watch (CRW) 5 km
daily satellite heat-stress products **inside the official ONMS sanctuary boundaries**, with
the CRW regional virtual stations carried alongside as a comparison layer.

```
ONMS boundary zips ─► normalise (CRS, antimeridian, units) ─► pixel inventory (fractional cover × cos lat, land-masked)
                                                                   │
ERDDAP NOAA_DHW (SST, SSTA, HotSpot, DHW, BAA) ─ monthly chunks ─► daily zonal stats per sanctuary / unit
                                                                   │
                                       monthly + 1991–2020 climatology + anomaly ─► data/<site>/*.csv ─► site/ viewer
CRW regional station .txt ─► station_daily / station_monthly (comparison only) ───────────────────────┘
```

## Easiest way: run from your IDE (Windows-friendly)

1. Install [Miniconda](https://docs.conda.io/en/latest/miniconda.html), open **Anaconda Prompt** in this folder and run
   `conda env create -f environment.yml` (one time).
2. Open the folder in VS Code / PyCharm / Spyder and select the **onms-crw** environment as the interpreter.
3. Open `run_pipeline.py`, set `MODE` (and `SITES` / `START`) in the SETTINGS block, press Run.

Suggested first runs, in order: `MODE = "test"` → `"demo"` → `"inspect"` → `"update"` with
`SITES = ["FKNMS"]`, `START = "2024-01-01"`. The viewer opens in your browser at the end; stop the
run in the IDE to close it. Close any CSV you have open in Excel before re-running.

## Quick start (command line)

```bash
pip install -e ".[test]"
pytest -q                                  # 12 tests, all offline

onms-crw inspect FKNMS                     # download a boundary zip, list layers/attributes
onms-crw update FKNMS                      # first run backfills from 1985-04-01, later runs are incremental
onms-crw update                            # all enabled sites (config/sanctuaries.toml)
onms-crw update NMSAS --start 2023-01-01 --end 2023-12-31   # repair / re-fetch a range

python -m http.server 8000                 # from the repo root, then open http://localhost:8000/site/
```

No network? `onms-crw demo demo/` builds a **synthetic** project (two made-up sanctuaries, one
crossing 180°, a land-locked unit, a gap day) and runs the real pipeline on it. The viewer shows a
banner whenever it is looking at synthetic data.

## What lands in `data/<site>/`

| File | Contents |
| --- | --- |
| `daily.csv` | One row per date × series (`ALL` = whole sanctuary, plus each unit when `unit_field` is set): pixels reporting, valid-area fraction, area-weighted SST mean and p10/p50/p90/min/max, CRW SSTA mean and p90, HotSpot max, DHW mean/p90/max, share of area with DHW ≥ 4 and ≥ 8, BAA max and share of area at each of the 8 v3.1 alert levels |
| `recent_daily.csv` | Last ~5 years of `daily.csv` (what the viewer loads) |
| `monthly.csv` | Days reported, `complete_month`, mean SST and band, **sanctuary 1991–2020 anomaly**, CRW SSTA mean, DHW max / peak area mean, BAA max, days with Alert 1+, peak area share at Alert 1+ and 2+ |
| `climatology.csv` | Calendar-month 1991–2020 means, year counts, `published` flag (≥ 25 complete years) |
| `pixels.csv` | The pixel inventory: lat, lon, grid indices, cover fraction, weight, `fallback` flag |
| `latest_pixels.csv` | Per-pixel SST, SSTA, DHW, BAA on the latest day (map layer) |
| `boundary.geojson` | Simplified boundary per series, in the frame used for processing |
| `station_daily.csv`, `station_monthly.csv` | CRW regional virtual station, if one is configured |
| `site.json` | Boundary digest, pixel counts per series, last date, QC notes |

`data/manifest.json` indexes all sites for the viewer.

## Automation

`.github/workflows/update.yml` runs daily at 19:17 UTC: installs the package, restores the boundary
cache, runs `onms-crw update --keep-going`, commits changed CSVs, and deploys `site/` + `data/` to
GitHub Pages. A manual dispatch accepts sites, `start` and `end` for backfills and repairs.

Each run re-fetches the last 10 days (`lookback_days`) to absorb late or corrected NRT files.
Backfills checkpoint `daily.csv` every 24 months, so a run that times out simply resumes next time.
If a boundary file changes, its digest changes and that site's history is rebuilt from scratch.

**Backfill sizing.** Requests are month-sized and split automatically above ~40 M cells.
FKNMS, FGBNMS, GRNMS, HIHWNMS and NMSAS are small (≈ 0.1–3 MB per month). Papahānaumokuākea is
the outlier: ~1.5 M km², ≈ 50 k water pixels across two windows straddling 180°, roughly 60 MB
per month and ~30 GB for 1985–present. Backfill it on a workstation (`onms-crw update PNMS`)
and commit the result, then let the Action run incrementally.

## Design decisions

* **All-touched, area-weighted pixels.** Every 0.05° cell touching the boundary is used, weighted
  by `cover fraction × cos(lat)`. Centre-in-polygon sampling silently drops small or narrow
  sanctuaries (the Flower Garden Banks banks, Gray's Reef, most NMSAS units).
* **Land mask from the data.** A one-day CRW SST probe marks which pixels CRW treats as water.
  Units with no water pixel at all (e.g. a small embayment) borrow the nearest water pixel
  within `fallback_km`, flagged in `pixels.csv` and on the map.
* **Antimeridian.** Geometries are processed in a 0–360° frame when they straddle 180°
  (Papahānaumokuākea's western boundary does) and fetched as two ERDDAP windows.
* **Two anomalies, clearly separated.** `sst_anom` is the sanctuary's own 1991–2020 monthly
  climatology (complete months only, published when ≥ 25 baseline years exist). `ssta_mean` is
  NOAA's pixel anomaly against CRW's 1985–2012 daily climatology. The viewer labels which is which.
* **Alert levels.** BAA uses the v3.1 codes 0–7 (Alert Levels 3–5 added Dec 2023). Because older
  BAA values could never exceed Alert 2, the DHW ≥ 4 / ≥ 8 area shares are provided as
  time-consistent equivalents for long-run comparison.
* **Fail loudly, write atomically.** Out-of-range values, off-grid windows, inconsistent time axes
  or duplicate dates stop a site before anything is written; files are replaced atomically.
  Missing ERDDAP days are never filled; they show up as `complete_month = 0` and in `site.json` QC.

## Notes on the regional-station pilot

The pilot (`pull_stations.py`) is solid and is folded in as `stations.py`. What changed:

1. **DHW and BAA were dropped from the monthly table.** For a Coral Reef Watch product those are
   the headline metrics; `station_monthly.csv` now keeps monthly DHW max, BAA max and days at
   Alert 1+.
2. **Header metadata is kept** (polygon midpoint, MMM, monthly mean climatology).
3. **A truncated final line no longer aborts the run** (the file can be caught mid-update); any
   other malformed line still does.
4. Range checks are physical (SST −2.5–40 °C, BAA 0–7) rather than ±100.
5. The station remains a **comparison** series only: NOAA's footprint is reef pixels + 20 km,
   not the sanctuary, and the SST is the value at whichever pixel holds the 90th-percentile
   HotSpot that day. The boundary-clipped series is the one to caption as "sanctuary".

## Configuration

`config/sanctuaries.toml` lists the six coral-relevant sanctuaries (enabled) and eight
temperate ocean sanctuaries (SST-only, disabled by default — CRW SST/SSTA are still useful for
marine heatwaves there). Boundary URLs come from the ONMS GIS download page. To report
sanctuary units separately (NMSAS is the obvious case — Muliava dominates the area mean),
run `onms-crw inspect NMSAS` and set `unit_field` to the attribute that names the units.

## Known limits / next steps

* Network access to ERDDAP and the ONMS site was not available while this was built, so the
  pipeline was verified against synthetic ERDDAP-shaped data. The first real run should be
  `onms-crw inspect` (confirm each zip's layer and CRS) then `onms-crw update FKNMS --start 2024-01-01`
  as a smoke test before a full backfill.
* The whole-sanctuary mean includes deep water. A reef-pixel mask (e.g. CRW's own reef-containing
  pixels, or Allen Coral Atlas) would be a natural second series.
* Publishing: the CSVs and `boundary.geojson` load directly as ArcGIS Online hosted tables /
  layers, so the same outputs can feed an Experience Builder app instead of (or as well as)
  the static viewer.
* A pixel-level product could be re-gridded to H3 cells for overlay with other sanctuary layers.

Data: NOAA Coral Reef Watch (2018, updated daily). *NOAA Coral Reef Watch Version 3.1 Daily Global
5km Satellite Coral Bleaching Degree Heating Week Product.* College Park, MD: NOAA Coral Reef Watch.
Boundaries: NOAA Office of National Marine Sanctuaries.
